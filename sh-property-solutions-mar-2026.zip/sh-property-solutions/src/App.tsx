import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from '@/src/components/Navbar';
import Footer from '@/src/components/Footer';
import Home from '@/src/pages/Home';
import Onboarding from '@/src/pages/Onboarding';
import Maintenance from '@/src/pages/Maintenance';
import Billing from '@/src/pages/Billing';
import Communication from '@/src/pages/Communication';
import Blog from '@/src/pages/Blog';
import TownLanding from '@/src/pages/TownLanding';
import GlobalChatbot from '@/src/components/GlobalChatbot';
import MobileCTA from '@/src/components/MobileCTA';
import { ThemeProvider } from '@/src/context/ThemeContext';

export default function App() {
  return (
    <ThemeProvider>
      <Router>
        <div className="min-h-screen bg-[var(--color-brand-cream)] dark:bg-[var(--color-brand-900)] font-sans selection:bg-amber-100 selection:text-amber-900 transition-colors duration-300">
          <Navbar />
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/onboarding" element={<Onboarding />} />
            <Route path="/maintenance" element={<Maintenance />} />
            <Route path="/billing" element={<Billing />} />
            <Route path="/communication" element={<Communication />} />
            <Route path="/blog" element={<Blog />} />
            {/* SEO Town Landing Pages */}
            <Route path="/services/:town" element={<TownLanding />} />
          </Routes>
          <Footer />
          <GlobalChatbot />
          <MobileCTA />
        </div>
      </Router>
    </ThemeProvider>
  );
}
