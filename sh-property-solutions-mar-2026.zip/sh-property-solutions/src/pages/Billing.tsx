import React from 'react';
import { motion } from 'motion/react';
import { CreditCard, History, Download, AlertCircle, CheckCircle2, DollarSign, Shield, ArrowUpRight } from 'lucide-react';
import { cn } from '@/src/lib/utils';

const transactions = [
  { id: 'SH-INV-041', type: 'The Snowbird — March', amount: 75, date: '2026-03-01', status: 'paid' },
  { id: 'SH-INV-038', type: 'Deck Repair (One-Off)', amount: 480, date: '2026-02-18', status: 'paid' },
  { id: 'SH-INV-035', type: 'The Snowbird — February', amount: 75, date: '2026-02-01', status: 'paid' },
  { id: 'SH-INV-029', type: 'The Snowbird — January', amount: 75, date: '2026-01-01', status: 'paid' },
];

const plans = [
  { name: 'The Retainer', price: '$49/mo', desc: 'Priority booking & 2x annual visits.', active: false },
  { name: 'The Snowbird', price: '$75/mo', desc: 'Your current plan. Video Vault access.', active: true },
  { name: 'The Reliability', price: '$125/mo', desc: 'IoT sensor monitoring for generators, wells & more.', active: false },
  { name: 'The Seasonal', price: '$250+/mo', desc: 'Full 20-point checklists + Detailed Health Reports.', active: false },
];

export default function Billing() {
  return (
    <div className="pt-32 pb-20 min-h-screen bg-[var(--color-brand-cream)] dark:bg-[#1a1612] transition-colors duration-300">
      <div className="max-w-7xl mx-auto px-6">
        <div className="mb-12">
          <h2 className="text-xs font-bold text-[#c8872b] uppercase tracking-[0.25em] mb-3 font-sans">Account</h2>
          <h1 className="text-4xl lg:text-5xl font-display text-stone-900 dark:text-stone-100 mb-2">Stewardship Billing</h1>
          <p className="text-stone-500 dark:text-stone-400 text-lg font-medium">Manage your subscription, view invoices, and download reports.</p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-8">
            {/* Current Plan */}
            <div className="p-8 bg-white dark:bg-[#292117] rounded-2xl border border-stone-200 dark:border-stone-700/50 shadow-sm relative overflow-hidden">
              <div className="absolute top-0 right-0 p-8 opacity-[0.04]">
                <Shield size={140} />
              </div>
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 relative">
                <div>
                  <div className="text-xs font-bold text-stone-400 dark:text-stone-500 uppercase tracking-[0.2em] mb-1 font-sans">Current Plan</div>
                  <div className="text-4xl font-display text-stone-900 dark:text-stone-100">The Snowbird</div>
                  <div className="text-lg text-[#c8872b] font-bold font-sans">$75/month</div>
                  <div className="mt-2 flex items-center gap-2 text-[#5a7a5f] dark:text-emerald-400 text-sm font-semibold">
                    <CheckCircle2 size={16} />
                    Active — next billing April 1, 2026
                  </div>
                </div>
                <div className="flex gap-3">
                  <button className="px-6 py-3 bg-[#c8872b] text-white rounded-xl font-bold shadow-lg shadow-amber-900/15 hover:bg-[#b47825] transition-all">
                    Upgrade Plan
                  </button>
                  <button className="px-6 py-3 bg-stone-100 dark:bg-stone-800 text-stone-800 dark:text-stone-200 rounded-xl font-bold hover:bg-stone-200 dark:hover:bg-stone-700 transition-all">
                    Auto-Pay: ON
                  </button>
                </div>
              </div>
            </div>

            {/* Transactions */}
            <div className="bg-white dark:bg-[#292117] rounded-2xl border border-stone-200 dark:border-stone-700/50 shadow-sm overflow-hidden">
              <div className="p-6 border-b border-stone-200/60 dark:border-stone-700/50 flex items-center justify-between">
                <h2 className="font-display text-xl text-stone-900 dark:text-stone-100 flex items-center gap-2">
                  <History size={20} className="text-[#c8872b]" />
                  Invoice History
                </h2>
                <button className="text-sm font-bold text-[#c8872b] hover:text-[#b47825] flex items-center gap-1">Download All <ArrowUpRight size={14} /></button>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-left">
                  <thead>
                    <tr className="bg-stone-50 dark:bg-stone-800/30 text-[10px] font-bold text-stone-400 dark:text-stone-500 uppercase tracking-wider font-sans">
                      <th className="px-6 py-4">Invoice</th>
                      <th className="px-6 py-4">Description</th>
                      <th className="px-6 py-4">Amount</th>
                      <th className="px-6 py-4">Date</th>
                      <th className="px-6 py-4">Status</th>
                      <th className="px-6 py-4 text-right">PDF</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-stone-100 dark:divide-stone-800/50">
                    {transactions.map((tx) => (
                      <tr key={tx.id} className="hover:bg-stone-50 dark:hover:bg-stone-800/20 transition-colors">
                        <td className="px-6 py-4 font-mono text-sm text-stone-400">{tx.id}</td>
                        <td className="px-6 py-4 font-bold text-stone-800 dark:text-stone-200 text-sm">{tx.type}</td>
                        <td className="px-6 py-4 font-bold text-stone-800 dark:text-stone-200">${tx.amount}</td>
                        <td className="px-6 py-4 text-sm text-stone-500 dark:text-stone-400">{tx.date}</td>
                        <td className="px-6 py-4">
                          <span className="px-2.5 py-1 rounded-full bg-[#e8efe9] dark:bg-emerald-900/20 text-[#5a7a5f] dark:text-emerald-400 text-[10px] font-bold uppercase tracking-wider">{tx.status}</span>
                        </td>
                        <td className="px-6 py-4 text-right">
                          <button className="p-2 text-stone-400 hover:text-[#c8872b] transition-colors"><Download size={16} /></button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            <div className="p-8 bg-[#1a1612] rounded-2xl text-stone-100 shadow-xl border border-stone-800">
              <h3 className="text-xl font-display mb-6 flex items-center gap-2">
                <CreditCard size={22} className="text-[#c8872b]" />
                Payment Method
              </h3>
              <div className="space-y-4 mb-6">
                <div className="p-4 bg-white/5 rounded-xl border border-white/10 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-6 bg-stone-700 rounded flex items-center justify-center text-[8px] font-bold">VISA</div>
                    <div><div className="text-sm font-bold">•••• 4242</div><div className="text-[10px] text-stone-500">Expires 12/27</div></div>
                  </div>
                  <div className="text-[10px] font-bold text-[#c8872b] uppercase tracking-wider">Default</div>
                </div>
                <button className="w-full py-3 border border-dashed border-white/20 rounded-xl text-sm font-bold text-stone-500 hover:border-white/40 hover:text-stone-300 transition-all">+ Add New Method</button>
              </div>
              <div className="p-4 bg-[#c8872b]/10 rounded-xl border border-[#c8872b]/20">
                <div className="flex gap-3">
                  <AlertCircle size={16} className="text-[#c8872b] flex-shrink-0 mt-0.5" />
                  <p className="text-xs text-amber-200/80 leading-relaxed">Stewardship subscriptions bill on the 1st. One-off service calls generate separate detailed invoices.</p>
                </div>
              </div>
            </div>

            <div className="p-8 bg-white dark:bg-[#292117] rounded-2xl border border-stone-200 dark:border-stone-700/50 shadow-sm">
              <h3 className="font-display text-xl text-stone-900 dark:text-stone-100 mb-6">Plan Comparison</h3>
              <div className="space-y-4">
                {plans.map((plan) => (
                  <div key={plan.name} className={cn("flex gap-4 p-3 -mx-1 rounded-xl transition-all", plan.active ? "bg-[#c8872b]/10 border border-[#c8872b]/20" : "")}>
                    <div className={cn("w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0", plan.active ? "bg-[#c8872b] text-white" : "bg-stone-100 dark:bg-stone-800 text-stone-500")}>
                      <DollarSign size={18} />
                    </div>
                    <div>
                      <h4 className={cn("text-sm font-bold", plan.active ? "text-[#c8872b]" : "text-stone-800 dark:text-stone-200")}>{plan.name} — {plan.price}</h4>
                      <p className={cn("text-xs mt-0.5", plan.active ? "text-[#c8872b]/70" : "text-stone-500 dark:text-stone-400")}>{plan.desc}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
