import React from 'react';
import Hero from '@/src/components/Hero';
import Services from '@/src/components/Services';
import HowItWorks from '@/src/components/HowItWorks';
import HomeLogPreview from '@/src/components/HomeLogPreview';
import BeforeAfter from '@/src/components/BeforeAfter';
import Pricing from '@/src/components/Pricing';
import Comparison from '@/src/components/Comparison';
import ServiceArea from '@/src/components/ServiceArea';
import Reviews from '@/src/components/Reviews';
import FAQ from '@/src/components/FAQ';

export default function Home() {
  return (
    <main>
      <Hero />
      <Services />
      <HowItWorks />
      <HomeLogPreview />
      <BeforeAfter />
      <Pricing />
      <Comparison />
      <ServiceArea />
      <Reviews />
      <FAQ />
    </main>
  );
}
