import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Wrench, Clock, CheckCircle2, AlertCircle, Plus, Search, Filter, MapPin, X } from 'lucide-react';
import { cn } from '@/src/lib/utils';
import ChatIntake from '@/src/components/ChatIntake';

const mockRecords = [
  { id: 'SH-2026-041', title: 'Spring 20-Point Inspection', status: 'completed', date: '2026-03-01', priority: 'medium', address: 'Lakefront Cabin, New Meadows' },
  { id: 'SH-2026-042', title: 'Generator Startup & Test', status: 'in-progress', date: '2026-03-03', priority: 'high', address: 'Ranch Property, Council' },
  { id: 'SH-2026-043', title: 'Deck Staining & Repair', status: 'pending', date: '2026-03-04', priority: 'low', address: 'Mountain View Rd, Midvale' },
];

export default function Maintenance() {
  const [showChat, setShowChat] = useState(false);

  const maintenanceSystemInstruction = `You are a service request assistant for SH Property Solutions — a premium handyman and property stewardship company on Idaho's Highway 95 corridor (Midvale, Council, New Meadows).

Your goal is to gather the following information for a new SERVICE REQUEST:
1. Brief description of the work needed
2. Property location (which town on the corridor — Midvale, Council, New Meadows, or nearby)
3. Priority Level (Routine, Urgent, or Emergency)
4. Category (General Repair, Finish Carpentry, Seasonal Checklist, Smart Home/IoT, Painting/Drywall, Deck/Exterior, or Other)
5. Any access instructions (gate codes, key lockbox, etc.)
6. Are they a current Stewardship subscriber? (If yes, which tier)

IMPORTANT COMPLIANCE NOTES:
- If the described work sounds like it could exceed $2,000, mention that Idaho requires contractor registration for jobs over $1,999 and reassure them that SH Property Solutions is fully registered.
- If the work involves electrical, plumbing, or HVAC, let them know you'll route it to a licensed subcontractor partner via the "Trade Wall."
- Be professional, warm, and concise. Ask one question at a time.

Once you have all the information, summarize and say: "Thank you! Your service request has been submitted successfully."`;

  return (
    <div className="pt-32 pb-20 min-h-screen bg-[var(--color-brand-cream)] dark:bg-[#1a1612] transition-colors duration-300">
      <div className="max-w-7xl mx-auto px-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-12">
          <div>
            <h2 className="text-xs font-bold text-[#c8872b] uppercase tracking-[0.25em] mb-3 font-sans">Maintenance</h2>
            <h1 className="text-4xl lg:text-5xl font-display text-stone-900 dark:text-stone-100 mb-2">Service Requests</h1>
            <p className="text-stone-500 dark:text-stone-400 text-lg font-medium">Submit new work orders and track your property's service history.</p>
          </div>
          <button
            onClick={() => setShowChat(true)}
            className="inline-flex items-center justify-center gap-2 px-6 py-3 bg-[#c8872b] text-white rounded-xl font-bold shadow-lg shadow-amber-900/15 hover:bg-[#b47825] transition-all hover:-translate-y-0.5"
          >
            <Plus size={18} /> New Request
          </button>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Stats */}
          <div className="lg:col-span-3 grid grid-cols-1 sm:grid-cols-3 gap-6">
            {[
              { icon: Clock, value: '2', label: 'Active Requests', accent: 'bg-amber-50 dark:bg-amber-900/15 text-[#c8872b]' },
              { icon: CheckCircle2, value: '0', label: 'Safety Incidents', accent: 'bg-[#e8efe9] dark:bg-emerald-900/15 text-[#5a7a5f]' },
              { icon: Wrench, value: 'Smart', label: 'Estimates', accent: 'bg-stone-100 dark:bg-stone-800 text-stone-600 dark:text-stone-400' },
            ].map((stat) => (
              <div key={stat.label} className="p-6 bg-white dark:bg-[#292117] rounded-2xl border border-stone-200 dark:border-stone-700/50 shadow-sm flex items-center gap-4">
                <div className={`w-12 h-12 ${stat.accent} rounded-xl flex items-center justify-center`}><stat.icon size={24} /></div>
                <div>
                  <div className="text-2xl font-display text-stone-900 dark:text-stone-100">{stat.value}</div>
                  <div className="text-sm text-stone-500 dark:text-stone-400 font-medium">{stat.label}</div>
                </div>
              </div>
            ))}
          </div>

          {/* Records */}
          <div className="lg:col-span-2">
            <div className="bg-white dark:bg-[#292117] rounded-2xl border border-stone-200 dark:border-stone-700/50 shadow-sm overflow-hidden">
              <div className="p-6 border-b border-stone-200/60 dark:border-stone-700/50 flex items-center justify-between gap-4">
                <h2 className="font-display text-xl text-stone-900 dark:text-stone-100">Service Records</h2>
                <div className="flex items-center gap-2">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-stone-400" size={15} />
                    <input type="text" placeholder="Search..." className="pl-9 pr-4 py-2 bg-stone-50 dark:bg-stone-800 border border-stone-200 dark:border-stone-700 rounded-lg text-sm focus:ring-2 focus:ring-[#c8872b] outline-none w-48 dark:text-stone-200" />
                  </div>
                  <button className="p-2 bg-stone-50 dark:bg-stone-800 border border-stone-200 dark:border-stone-700 rounded-lg text-stone-500 hover:bg-stone-100 dark:hover:bg-stone-700"><Filter size={16} /></button>
                </div>
              </div>
              <div className="divide-y divide-stone-100 dark:divide-stone-800/50">
                {mockRecords.map((r) => (
                  <div key={r.id} className="p-6 hover:bg-stone-50 dark:hover:bg-stone-800/20 transition-colors cursor-pointer group">
                    <div className="flex items-start justify-between mb-2">
                      <div>
                        <div className="flex items-center gap-2 mb-1">
                          <span className="text-[10px] font-bold text-stone-400 uppercase tracking-wider font-sans">{r.id}</span>
                          <span className={cn("px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider",
                            r.priority === 'high' ? "bg-rose-50 dark:bg-rose-900/20 text-rose-600 dark:text-rose-400" :
                            r.priority === 'medium' ? "bg-amber-50 dark:bg-amber-900/20 text-[#c8872b]" : "bg-stone-100 dark:bg-stone-800 text-stone-500"
                          )}>{r.priority}</span>
                        </div>
                        <h3 className="text-lg font-display text-stone-900 dark:text-stone-100 group-hover:text-[#c8872b] transition-colors">{r.title}</h3>
                      </div>
                      <div className={cn("px-3 py-1 rounded-full text-[10px] font-bold flex items-center gap-1.5 font-sans",
                        r.status === 'completed' ? "bg-[#e8efe9] dark:bg-emerald-900/20 text-[#5a7a5f]" :
                        r.status === 'in-progress' ? "bg-sky-50 dark:bg-sky-900/20 text-sky-600" : "bg-stone-100 dark:bg-stone-800 text-stone-500"
                      )}>
                        <div className={cn("w-1.5 h-1.5 rounded-full", r.status === 'completed' ? "bg-[#5a7a5f]" : r.status === 'in-progress' ? "bg-sky-500" : "bg-stone-400")} />
                        {r.status.replace('-', ' ')}
                      </div>
                    </div>
                    <div className="flex items-center gap-4 text-sm text-stone-500 dark:text-stone-400">
                      <div className="flex items-center gap-1.5"><Clock size={13} /> {r.date}</div>
                      <div className="flex items-center gap-1.5"><MapPin size={13} /> {r.address}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            <div className="p-8 bg-[#c8872b] rounded-2xl text-white shadow-xl shadow-amber-900/20 relative overflow-hidden grain-overlay">
              <div className="absolute top-[-20%] right-[-20%] w-40 h-40 bg-white/10 rounded-full blur-2xl" />
              <h3 className="text-xl font-display mb-3 relative z-10">Emergency?</h3>
              <p className="text-amber-100/80 text-sm mb-6 relative z-10 leading-relaxed">For immediate property damage — flooding, fire, gas leak — call our emergency line.</p>
              <a href="tel:2083472500" className="inline-flex items-center gap-2 px-6 py-3 bg-white text-[#c8872b] rounded-xl font-bold hover:bg-amber-50 transition-all relative z-10 text-sm">(208) 347-2500</a>
            </div>

            <div className="p-8 bg-white dark:bg-[#292117] rounded-2xl border border-stone-200 dark:border-stone-700/50 shadow-sm">
              <h3 className="font-display text-lg text-stone-900 dark:text-stone-100 mb-5">Corridor Reminders</h3>
              <ul className="space-y-4">
                {[
                  { icon: AlertCircle, color: 'text-[#c8872b] bg-amber-50 dark:bg-amber-900/15', text: 'Quotes over $1,999 require Idaho Contractor Registration — we\'re covered.' },
                  { icon: CheckCircle2, color: 'text-[#5a7a5f] bg-[#e8efe9] dark:bg-emerald-900/15', text: 'Electrical, plumbing & HVAC routed to licensed subs via Trade Wall.' },
                  { icon: CheckCircle2, color: 'text-[#5a7a5f] bg-[#e8efe9] dark:bg-emerald-900/15', text: 'All jobs documented with before/after photos and detailed summaries.' },
                ].map((item, i) => (
                  <li key={i} className="flex gap-3 text-sm text-stone-600 dark:text-stone-400">
                    <div className={`w-5 h-5 ${item.color} rounded flex items-center justify-center flex-shrink-0 mt-0.5`}><item.icon size={11} /></div>
                    {item.text}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </div>

      {/* Chat Modal */}
      {showChat && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-6 bg-[#1a1612]/70 backdrop-blur-sm">
          <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} className="w-full max-w-2xl h-[700px] flex flex-col">
            <div className="p-6 bg-white dark:bg-[#292117] border-b border-stone-200/60 dark:border-stone-700/50 flex items-center justify-between rounded-t-2xl">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-[#c8872b] text-white rounded-xl flex items-center justify-center"><Wrench size={20} /></div>
                <div>
                  <h2 className="text-xl font-display text-stone-900 dark:text-stone-100">Service Request Assistant</h2>
                  <p className="text-xs text-stone-500 dark:text-stone-400">Smart Intake</p>
                </div>
              </div>
              <button onClick={() => setShowChat(false)} className="p-2 hover:bg-stone-100 dark:hover:bg-stone-800 rounded-xl transition-colors"><X size={20} className="text-stone-400" /></button>
            </div>
            <div className="flex-1 overflow-hidden rounded-b-2xl">
              <ChatIntake systemInstruction={maintenanceSystemInstruction} initialMessage="Hey there! I'll help you submit a service request for your property on the corridor. What kind of work do you need done?" onComplete={() => setTimeout(() => setShowChat(false), 3000)} />
            </div>
          </motion.div>
        </div>
      )}
    </div>
  );
}
