import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Home, Users, Wrench, ArrowRight } from 'lucide-react';
import ChatIntake from '@/src/components/ChatIntake';

type UserType = 'tenant' | 'landlord' | 'homeowner' | null;

export default function Onboarding() {
  const [type, setType] = useState<UserType>(null);

  const systemInstructions: Record<string, string> = {
    tenant: `You are an onboarding assistant for SH Property Solutions, a property management and handyman company serving Idaho's Highway 95 corridor (Midvale, Council, New Meadows).
Your goal is to gather: 1. Full Name 2. Phone Number or Email 3. Current Property Address 4. Landlord's Name (if known) 5. Move-in Date (if applicable) 6. Any immediate maintenance concerns.
Be friendly and concise. Ask one question at a time. Once done, summarize and say: "Thank you! Your tenant profile has been submitted successfully."`,
    landlord: `You are an onboarding assistant for SH Property Solutions serving Idaho's Highway 95 corridor.
Gather: 1. Full Name 2. Phone/Email 3. Number of properties (1-5, 6-20, 20+) 4. Locations (which towns) 5. Occupancy status 6. Which tier: Retainer ($49/mo), Snowbird ($75/mo), Reliability ($125/mo), Seasonal ($250+/mo), or one-off.
Be professional. Ask one question at a time. Once done: "Thank you! Your landlord profile has been submitted successfully."`,
    homeowner: `You are an onboarding assistant for SH Property Solutions serving Idaho's Highway 95 corridor.
Gather: 1. Full Name 2. Phone/Email 3. Property Address 4. Primary interest (General Handyman, Seasonal Maintenance, Smart Home setup, etc.).
Be professional and welcoming. Ask one question at a time. Once done: "Thank you! Your homeowner profile has been submitted successfully."`
  };

  const cards = [
    { type: 'tenant' as const, icon: Home, title: "I'm a Tenant", desc: 'Submit maintenance requests, communicate with your landlord and our service team — all in one place.', color: '#c8872b', cta: 'Get Started' },
    { type: 'homeowner' as const, icon: Wrench, title: "I'm a Homeowner", desc: 'Get reliable handyman services, seasonal maintenance, and peace of mind for your primary residence.', color: '#c8872b', cta: 'Get Started' },
    { type: 'landlord' as const, icon: Users, title: "I'm a Landlord", desc: 'Enroll your properties in a Stewardship plan. Get detailed reports, inspections, and reliable maintenance.', color: '#5a7a5f', cta: 'Start Onboarding' },
  ];

  const initMsgs: Record<string, string> = {
    tenant: "Welcome to SH Property Solutions! I'll get your tenant profile set up so you can start submitting requests. What's your full name?",
    landlord: "Welcome! I'll help you enroll your properties in a Stewardship plan along the Highway 95 corridor. What's your full name?",
    homeowner: "Thanks for choosing us for your home! Let's get your profile set up. What's your full name?",
  };

  return (
    <div className="pt-32 pb-20 min-h-screen bg-[var(--color-brand-cream)] dark:bg-[#1a1612] transition-colors duration-300">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <img src="/icon.png" alt="SH Icon" className="w-16 h-16 mx-auto mb-6 object-contain rounded-xl" onError={(e) => { if (e.currentTarget.src.includes('icon.png')) { e.currentTarget.src = '/icon.svg'; } else { e.currentTarget.src = 'https://placehold.co/100x100/c8872b/white?text=Icon'; } }} />
          <h2 className="text-xs font-bold text-[#c8872b] uppercase tracking-[0.25em] mb-3 font-sans">Welcome</h2>
          <h1 className="text-4xl lg:text-5xl font-display text-stone-900 dark:text-stone-100 mb-4">Get Started with SH Property Solutions</h1>
          <p className="text-stone-500 dark:text-stone-400 max-w-xl mx-auto font-medium">
            Whether you're a tenant, a homeowner, or a property owner — select your role to begin.
          </p>
        </div>

        {!type ? (
          <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            {cards.map((card) => (
              <motion.button
                key={card.type}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => setType(card.type)}
                className="p-10 bg-white dark:bg-[#292117] rounded-2xl border border-stone-200 dark:border-stone-700/50 shadow-sm hover:shadow-xl transition-all text-left group"
                style={{ ['--card-color' as any]: card.color }}
              >
                <div className="w-16 h-16 rounded-2xl flex items-center justify-center mb-6 transition-colors"
                  style={{ backgroundColor: `${card.color}15`, color: card.color }}>
                  <card.icon size={32} />
                </div>
                <h3 className="text-2xl font-display text-stone-900 dark:text-stone-100 mb-3">{card.title}</h3>
                <p className="text-stone-500 dark:text-stone-400 mb-6 text-sm leading-relaxed">{card.desc}</p>
                <div className="flex items-center gap-2 font-bold text-sm" style={{ color: card.color }}>
                  {card.cta} <ArrowRight size={16} />
                </div>
              </motion.button>
            ))}
          </div>
        ) : (
          <div className="max-w-2xl mx-auto">
            <div className="mb-4 flex items-center justify-between">
              <button onClick={() => setType(null)} className="text-sm font-bold text-stone-400 hover:text-[#c8872b] flex items-center gap-2 transition-colors">
                <ArrowRight size={14} className="rotate-180" /> Back
              </button>
              <span className="text-[10px] font-bold text-stone-400 uppercase tracking-widest font-sans">Streamlined Onboarding</span>
            </div>
            <div className="h-[600px]">
              <ChatIntake systemInstruction={systemInstructions[type]} initialMessage={initMsgs[type]} />
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
