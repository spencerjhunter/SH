import React from 'react';
import { useParams, Link, Navigate } from 'react-router-dom';
import { motion } from 'motion/react';
import { ArrowRight, CheckCircle2, MapPin, Phone, Shield, Wrench, Snowflake, Home, Clock } from 'lucide-react';

interface TownData {
  name: string;
  tagline: string;
  description: string;
  population: string;
  medianHome: string;
  keyFact: string;
  services: string[];
  seoTitle: string;
  image: string;
}

const towns: Record<string, TownData> = {
  'new-meadows': {
    name: 'New Meadows',
    tagline: 'Property Stewardship for the Gateway to McCall',
    description: "New Meadows sits at the northern reach of our Highway 95 corridor — where snowbird cabins meet year-round ranches and the seasonal population swings create enormous demand for reliable property care. If you're away for winter or just need someone you can count on, we're your local team.",
    population: '~500',
    medianHome: '$380K',
    keyFact: 'Heavy seasonal/snowbird ownership. Many properties sit vacant 4-8 months per year — our Snowbird Watch plan was designed specifically for this.',
    services: ['Snowbird Property Watch & Video Vault', 'Spring/Fall 20-Point Seasonal Checklists', 'Freeze Prevention & Storm Monitoring', 'General Handyman & Finish Carpentry', 'Smart Home & IoT Sensor Setup', 'Licensed Trade Referrals (Plumbing, Electrical, HVAC)'],
    seoTitle: 'Handyman & Property Management in New Meadows, Idaho',
    image: 'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?auto=format&fit=crop&q=80&w=800',
  },
  'council': {
    name: 'Council',
    tagline: 'Our Home Base — Property Care for Adams County',
    description: "Council is where SH Property Solutions is headquartered. Our physical office on Main Street means we're not a remote platform — we're your neighbors. With a median age over 60 and aging housing stock dating to the 1940s-1970s, Council needs reliable property maintenance more than almost anywhere on the corridor.",
    population: '~830',
    medianHome: '$368K',
    keyFact: 'Median age 61.5 with 34% of residents over 65. Aging-in-place modifications and regular maintenance are growing needs.',
    services: ['Priority Handyman Service for Residents', 'Aging-in-Place Modifications', 'Seasonal Inspections & Winterization', 'Deck, Siding & Exterior Repairs', 'Digital Home Log for Every Property', 'Licensed Trade Referrals (Plumbing, Electrical, HVAC)'],
    seoTitle: 'Handyman & Property Maintenance in Council, Idaho',
    image: 'https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&q=80&w=800',
  },
  'midvale': {
    name: 'Midvale',
    tagline: 'Reliable Property Care at the Southern Corridor',
    description: "Midvale anchors the southern end of our Highway 95 service area. With housing stock where 32% of units were built before 1940, the need for steady, professional maintenance isn't a luxury — it's essential. And until SH Property Solutions, there were effectively zero professional handymen serving this community.",
    population: '~200',
    medianHome: '$212K',
    keyFact: 'Median-year-built for housing is 1972 with a third of homes pre-1940. Affordable entry point for Boise investors seeking second homes.',
    services: ['General Repairs & Home Maintenance', 'Drywall, Painting & Interior Work', 'Seasonal Property Inspections', 'Remote Owner Property Checks', 'Emergency Repairs & Response', 'Licensed Trade Referrals (Plumbing, Electrical, HVAC)'],
    seoTitle: 'Handyman & Property Maintenance in Midvale, Idaho',
    image: 'https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&q=80&w=800',
  },
};

export default function TownLanding() {
  const { town } = useParams<{ town: string }>();
  const data = town ? towns[town] : null;

  if (!data) return <Navigate to="/" replace />;

  return (
    <div className="pt-32 pb-20 min-h-screen bg-[var(--color-brand-cream)] dark:bg-[#1a1612] transition-colors duration-300">
      {/* Hero */}
      <section className="relative mb-20">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
              <div className="inline-flex items-center gap-2 px-4 py-2 bg-[#e8efe9] dark:bg-[#5a7a5f]/20 text-[#5a7a5f] dark:text-[#8ab08f] rounded-full text-xs font-bold uppercase tracking-[0.15em] mb-6 border border-[#5a7a5f]/20">
                <MapPin size={14} />
                {data.name}, Idaho
              </div>

              <h1 className="text-4xl lg:text-5xl font-display text-stone-900 dark:text-stone-100 mb-4 leading-tight">{data.tagline}</h1>
              <p className="text-lg text-stone-600 dark:text-stone-400 mb-8 leading-relaxed font-medium">{data.description}</p>

              <div className="flex flex-col sm:flex-row gap-4 mb-10">
                <Link to="/maintenance" className="inline-flex items-center justify-center gap-2 px-8 py-4 bg-[#c8872b] text-white rounded-2xl font-bold shadow-xl shadow-amber-900/15 hover:bg-[#b47825] transition-all">
                  Request Service in {data.name} <ArrowRight size={18} />
                </Link>
                <a href="tel:2083472500" className="inline-flex items-center justify-center gap-2 px-8 py-4 bg-white dark:bg-[#292117] text-stone-800 dark:text-stone-200 border-2 border-stone-200 dark:border-stone-700 rounded-2xl font-bold hover:border-[#c8872b] transition-all">
                  <Phone size={18} /> (208) 347-2500
                </a>
              </div>

              {/* Trust bar */}
              <div className="flex flex-wrap gap-4">
                {['Idaho Licensed', '$1M Insured', 'Background-Checked'].map((t) => (
                  <div key={t} className="flex items-center gap-1.5 text-sm text-stone-500 dark:text-stone-400 font-medium">
                    <CheckCircle2 size={14} className="text-[#5a7a5f]" /> {t}
                  </div>
                ))}
              </div>
            </motion.div>

            <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} transition={{ delay: 0.1 }}>
              <div className="rounded-2xl overflow-hidden shadow-2xl shadow-stone-900/15 border-[5px] border-white dark:border-stone-800">
                <img src={data.image} alt={`Property in ${data.name}, Idaho`} className="w-full aspect-[4/3] object-cover" referrerPolicy="no-referrer" />
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      <div className="max-w-7xl mx-auto px-6">
        {/* Stats */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 mb-20">
          {[
            { icon: Home, label: 'Population', value: data.population },
            { icon: Shield, label: 'Median Home Value', value: data.medianHome },
            { icon: Clock, label: 'Service Area', value: 'Same-day triage' },
          ].map((s) => (
            <div key={s.label} className="p-6 bg-white dark:bg-[#292117] rounded-2xl border border-stone-200 dark:border-stone-700/50 shadow-sm flex items-center gap-4">
              <div className="w-12 h-12 bg-amber-50 dark:bg-amber-900/15 text-[#c8872b] rounded-xl flex items-center justify-center"><s.icon size={22} /></div>
              <div>
                <div className="text-2xl font-display text-stone-900 dark:text-stone-100">{s.value}</div>
                <div className="text-sm text-stone-500 dark:text-stone-400 font-medium">{s.label}</div>
              </div>
            </div>
          ))}
        </div>

        {/* Key Fact */}
        <div className="p-8 bg-[#1a1612] text-stone-100 rounded-2xl mb-20 relative overflow-hidden grain-overlay">
          <div className="absolute top-0 right-0 w-[30%] h-full bg-gradient-to-l from-[#c8872b]/5 to-transparent" />
          <div className="relative z-10 max-w-3xl">
            <h2 className="text-xs font-bold text-[#c8872b] uppercase tracking-[0.25em] mb-3 font-sans">Local Insight</h2>
            <p className="text-xl font-display text-stone-100 mb-3">Why {data.name} needs SH Property Solutions</p>
            <p className="text-stone-400 leading-relaxed font-medium">{data.keyFact}</p>
          </div>
        </div>

        {/* Services */}
        <div className="mb-20">
          <h2 className="text-3xl font-display text-stone-900 dark:text-stone-100 mb-8">Services Available in {data.name}</h2>
          <div className="grid md:grid-cols-2 gap-4">
            {data.services.map((service) => (
              <div key={service} className="flex items-center gap-4 p-5 bg-white dark:bg-[#292117] rounded-xl border border-stone-200 dark:border-stone-700/50 shadow-sm">
                <div className="w-10 h-10 bg-[#e8efe9] dark:bg-emerald-900/15 text-[#5a7a5f] rounded-xl flex items-center justify-center flex-shrink-0">
                  <Wrench size={18} />
                </div>
                <span className="text-stone-700 dark:text-stone-300 font-medium">{service}</span>
              </div>
            ))}
          </div>
        </div>

        {/* CTA */}
        <div className="p-10 bg-[#c8872b] rounded-2xl text-white text-center relative overflow-hidden grain-overlay">
          <div className="absolute top-[-30%] right-[-10%] w-[40%] h-[80%] bg-white/5 rounded-full blur-[80px]" />
          <div className="relative z-10">
            <h2 className="text-3xl font-display mb-4">Ready to get started in {data.name}?</h2>
            <p className="text-amber-100/80 mb-8 max-w-lg mx-auto font-medium">Submit a service request, explore Stewardship plans, or just call us. We're right down the road in Council.</p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link to="/maintenance" className="inline-flex items-center justify-center gap-2 px-8 py-4 bg-white text-[#c8872b] rounded-2xl font-bold hover:bg-amber-50 transition-all">
                Request Service <ArrowRight size={18} />
              </Link>
              <Link to="/onboarding" className="inline-flex items-center justify-center px-8 py-4 bg-white/10 text-white border border-white/20 rounded-2xl font-bold hover:bg-white/20 transition-all">
                View Plans
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
