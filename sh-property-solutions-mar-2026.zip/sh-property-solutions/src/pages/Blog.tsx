import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Mail, ArrowRight, Play, Calendar, Clock, Tag, CheckCircle2, ChevronRight, Rss } from 'lucide-react';
import { cn } from '@/src/lib/utils';

const featuredPost = {
  id: 'spring-checklist-2026', title: 'The 20-Point Spring Checklist Every Idaho Property Owner Needs',
  excerpt: "Winter hit hard this year along Highway 95. Here's exactly what we inspect — and why skipping it costs you more later.",
  date: 'March 4, 2026', readTime: '6 min read', category: 'Seasonal Tips',
  image: 'https://images.unsplash.com/photo-1558618666-fcd25c85f82e?auto=format&fit=crop&q=80&w=800',
};

const posts = [
  { id: '1', title: 'Before & After: Council Cabin Deck Restoration', excerpt: "This cedar deck hadn't been touched in 5 years. Here's the full process with results.", date: 'Feb 22, 2026', readTime: '4 min', category: 'Project Showcase', image: 'https://images.unsplash.com/photo-1591825729269-caeb344f6df2?auto=format&fit=crop&q=80&w=400' },
  { id: '2', title: 'Why Your Backup Generator Needs More Than an Annual Start', excerpt: "We see it every winter — generators that won't fire when the power goes out.", date: 'Feb 14, 2026', readTime: '5 min', category: 'Maintenance Tips', image: 'https://images.unsplash.com/photo-1621905252507-b35492cc74b4?auto=format&fit=crop&q=80&w=400' },
  { id: '3', title: 'What Our Snowbird Clients See Every Month (Sample Report)', excerpt: 'A walkthrough of an actual comprehensive property report — what we check and what you receive.', date: 'Feb 6, 2026', readTime: '3 min', category: 'How It Works', image: 'https://images.unsplash.com/photo-1480074568708-e7b720bb3f09?auto=format&fit=crop&q=80&w=400' },
  { id: '4', title: "Idaho's $2,000 Rule: What Homeowners Need to Know in 2026", excerpt: 'If your project crosses $1,999, Idaho law requires a registered contractor.', date: 'Jan 28, 2026', readTime: '4 min', category: 'Regulations', image: 'https://images.unsplash.com/photo-1450101499163-c8848c66ca85?auto=format&fit=crop&q=80&w=400' },
];

const videos = [
  { id: 'v1', title: 'Full Walkthrough: Spring Inspection in New Meadows', duration: '8:24', thumbnail: 'https://images.unsplash.com/photo-1564013799919-ab600027ffc6?auto=format&fit=crop&q=80&w=500' },
  { id: 'v2', title: 'Before & After: Midvale Kitchen Remodel', duration: '5:12', thumbnail: 'https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?auto=format&fit=crop&q=80&w=500' },
  { id: 'v3', title: 'How We Create Detailed Property Reports', duration: '6:45', thumbnail: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&q=80&w=500' },
];

const categories = ['All', 'Project Showcase', 'Seasonal Tips', 'Maintenance Tips', 'How It Works', 'Regulations'];

export default function Blog() {
  const [email, setEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);
  const [activeCategory, setActiveCategory] = useState('All');
  const filteredPosts = activeCategory === 'All' ? posts : posts.filter(p => p.category === activeCategory);

  return (
    <div className="pt-32 pb-20 min-h-screen bg-[var(--color-brand-cream)] dark:bg-[#1a1612] transition-colors duration-300">
      <div className="max-w-7xl mx-auto px-6">

        {/* Header */}
        <div className="mb-16">
          <div className="mb-10">
            <div className="inline-flex items-center gap-2 px-3 py-1.5 bg-amber-50 dark:bg-amber-900/15 text-[#c8872b] rounded-full text-[10px] font-bold uppercase tracking-[0.2em] mb-4 font-sans">
              <Rss size={12} /> Blog & Updates
            </div>
            <h1 className="text-4xl lg:text-5xl font-display text-stone-900 dark:text-stone-100 mb-2">The Corridor Chronicle</h1>
            <p className="text-stone-500 dark:text-stone-400 text-lg font-medium">Project showcases, seasonal tips, and property insights from the Highway 95 corridor.</p>
          </div>

          {/* Newsletter */}
          <div className="p-8 bg-[#c8872b] rounded-2xl text-white relative overflow-hidden shadow-xl shadow-amber-900/20 grain-overlay">
            <div className="absolute top-[-30%] right-[-10%] w-[40%] h-[80%] bg-white/5 rounded-full blur-[80px]" />
            <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
              <div>
                <div className="flex items-center gap-2 mb-2"><Mail size={18} /><h3 className="text-lg font-display">Stay in the loop</h3></div>
                <p className="text-amber-100/80 text-sm max-w-md">Project before & afters, seasonal reminders, and corridor news. No spam — just useful stuff.</p>
              </div>
              {subscribed ? (
                <div className="flex items-center gap-3 px-6 py-4 bg-white/10 rounded-xl backdrop-blur-sm">
                  <CheckCircle2 size={22} className="text-emerald-300" />
                  <span className="font-bold text-sm">You're subscribed!</span>
                </div>
              ) : (
                <form onSubmit={(e) => { e.preventDefault(); if (email.trim()) { setSubscribed(true); setEmail(''); } }} className="flex gap-3 w-full md:w-auto">
                  <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="your@email.com" required className="flex-1 md:w-72 px-5 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-amber-200/50 outline-none focus:ring-2 focus:ring-white/40 text-sm backdrop-blur-sm" />
                  <button type="submit" className="px-6 py-3 bg-white text-[#c8872b] rounded-xl font-bold hover:bg-amber-50 transition-all flex items-center gap-2 whitespace-nowrap text-sm">
                    Subscribe <ArrowRight size={14} />
                  </button>
                </form>
              )}
            </div>
          </div>
        </div>

        {/* Featured */}
        <div className="mb-16">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}
            className="group grid md:grid-cols-2 gap-0 bg-white dark:bg-[#292117] rounded-2xl border border-stone-200 dark:border-stone-700/50 shadow-sm overflow-hidden hover:shadow-xl transition-all cursor-pointer">
            <div className="relative overflow-hidden">
              <img src={featuredPost.image} alt={featuredPost.title} className="w-full h-full object-cover min-h-[300px] group-hover:scale-105 transition-transform duration-500" referrerPolicy="no-referrer" />
              <div className="absolute top-4 left-4 px-3 py-1.5 bg-[#c8872b] text-white text-[10px] font-bold uppercase tracking-wider rounded-full font-sans">Featured</div>
            </div>
            <div className="p-10 flex flex-col justify-center">
              <div className="flex items-center gap-3 mb-4 text-xs text-stone-500 dark:text-stone-400 font-medium font-sans">
                <span className="px-2.5 py-1 bg-amber-50 dark:bg-amber-900/15 text-[#c8872b] rounded-full font-bold uppercase tracking-wider text-[10px]">{featuredPost.category}</span>
                <span className="flex items-center gap-1"><Calendar size={11} /> {featuredPost.date}</span>
                <span className="flex items-center gap-1"><Clock size={11} /> {featuredPost.readTime}</span>
              </div>
              <h2 className="text-2xl font-display text-stone-900 dark:text-stone-100 mb-4 group-hover:text-[#c8872b] transition-colors">{featuredPost.title}</h2>
              <p className="text-stone-500 dark:text-stone-400 leading-relaxed mb-6">{featuredPost.excerpt}</p>
              <div className="flex items-center gap-2 text-[#c8872b] font-bold text-sm">Read More <ChevronRight size={14} /></div>
            </div>
          </motion.div>
        </div>

        {/* Videos */}
        <div className="mb-16">
          <h2 className="text-2xl font-display text-stone-900 dark:text-stone-100 mb-2">Latest Videos</h2>
          <p className="text-stone-500 dark:text-stone-400 text-sm mb-8 font-medium">Walkthroughs, project showcases, and how-to guides.</p>
          <div className="grid md:grid-cols-3 gap-6">
            {videos.map((v, i) => (
              <motion.div key={v.id} initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.1 }}
                className="group bg-white dark:bg-[#292117] rounded-2xl border border-stone-200 dark:border-stone-700/50 shadow-sm overflow-hidden hover:shadow-xl transition-all cursor-pointer">
                <div className="relative">
                  <img src={v.thumbnail} alt={v.title} className="w-full aspect-video object-cover group-hover:scale-105 transition-transform duration-500" referrerPolicy="no-referrer" />
                  <div className="absolute inset-0 bg-black/20 group-hover:bg-black/40 transition-colors flex items-center justify-center">
                    <div className="w-14 h-14 bg-white/90 rounded-full flex items-center justify-center shadow-xl group-hover:scale-110 transition-transform">
                      <Play size={22} className="text-[#c8872b] ml-1" fill="currentColor" />
                    </div>
                  </div>
                  <div className="absolute bottom-3 right-3 px-2.5 py-1 bg-black/70 text-white text-xs font-bold rounded-lg backdrop-blur-sm">{v.duration}</div>
                </div>
                <div className="p-5">
                  <h3 className="font-bold text-stone-800 dark:text-stone-200 text-sm group-hover:text-[#c8872b] transition-colors leading-snug">{v.title}</h3>
                </div>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Posts */}
        <div>
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
            <h2 className="text-2xl font-display text-stone-900 dark:text-stone-100">All Posts</h2>
            <div className="flex flex-wrap gap-2">
              {categories.map((cat) => (
                <button key={cat} onClick={() => setActiveCategory(cat)}
                  className={cn("px-4 py-2 rounded-xl text-[10px] font-bold uppercase tracking-wider transition-all font-sans",
                    activeCategory === cat
                      ? "bg-[#c8872b] text-white shadow-lg shadow-amber-900/15"
                      : "bg-white dark:bg-[#292117] text-stone-500 dark:text-stone-400 border border-stone-200 dark:border-stone-700/50 hover:border-[#c8872b]/40"
                  )}>{cat}</button>
              ))}
            </div>
          </div>
          <div className="grid md:grid-cols-2 gap-6">
            {filteredPosts.map((p, i) => (
              <motion.div key={p.id} initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.08 }}
                className="group bg-white dark:bg-[#292117] rounded-2xl border border-stone-200 dark:border-stone-700/50 shadow-sm overflow-hidden hover:shadow-xl transition-all cursor-pointer flex">
                <div className="w-1/3 min-w-[140px] relative overflow-hidden">
                  <img src={p.image} alt={p.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" referrerPolicy="no-referrer" />
                </div>
                <div className="flex-1 p-6 flex flex-col justify-center">
                  <div className="flex items-center gap-3 mb-3 text-[10px] text-stone-400 font-bold uppercase tracking-wider font-sans">
                    <span className="flex items-center gap-1"><Tag size={10} /> {p.category}</span>
                    <span>{p.date}</span>
                  </div>
                  <h3 className="font-display text-stone-900 dark:text-stone-100 mb-2 group-hover:text-[#c8872b] transition-colors leading-snug">{p.title}</h3>
                  <p className="text-stone-500 dark:text-stone-400 text-sm leading-relaxed line-clamp-2">{p.excerpt}</p>
                </div>
              </motion.div>
            ))}
          </div>
          {filteredPosts.length === 0 && <div className="text-center py-16"><p className="text-stone-400">No posts in this category yet.</p></div>}
        </div>
      </div>
    </div>
  );
}
