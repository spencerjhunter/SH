import React, { useState } from 'react';
import { Send, Search, Home, User, CheckCheck, FileText, Camera, Video, ClipboardList } from 'lucide-react';
import { cn } from '@/src/lib/utils';

const contacts = [
  { id: 1, name: 'SH Service Team', lastMsg: 'Your spring inspection report is ready.', time: '10:30 AM', unread: 1, online: true },
  { id: 2, name: 'Trade Partner: Mike (Plumbing)', lastMsg: 'Water heater quote attached — $1,450.', time: 'Yesterday', unread: 0, online: false },
  { id: 3, name: 'Property Reports', lastMsg: 'March Snowbird walkthrough summary available.', time: 'Mar 1', unread: 1, online: true },
];

const messages = [
  { id: 1, text: 'Good morning! Your Spring 20-point inspection has been completed for the New Meadows lakefront cabin.', time: '10:00 AM', me: false },
  { id: 2, text: 'Great — how did it look? Any issues?', time: '10:05 AM', me: true },
  { id: 3, text: 'Overall the property is in good shape. Two items flagged: the deck stain is peeling on the south-facing side, and one smoke detector battery needs replacing. Full report with photos is in your Home Log.', time: '10:06 AM', me: false },
  { id: 4, text: "I can schedule the deck re-staining as a separate work order if you'd like — estimated around $350-$480 for your deck size. Want me to set that up?", time: '10:30 AM', me: false },
];

const quickActions = [
  { icon: Camera, label: 'Video Vault', desc: '360° walkthroughs' },
  { icon: FileText, label: 'Home Log', desc: 'Property vitals' },
  { icon: ClipboardList, label: 'Reports', desc: 'Detailed summaries' },
  { icon: Video, label: 'Inspections', desc: 'Before & after' },
];

export default function Communication() {
  const [activeContact, setActiveContact] = useState(contacts[0]);
  const [msgInput, setMsgInput] = useState('');

  return (
    <div className="pt-32 pb-20 min-h-screen bg-[var(--color-brand-cream)] dark:bg-[#1a1612] transition-colors duration-300">
      <div className="max-w-7xl mx-auto px-6">
        <div className="mb-8">
          <h2 className="text-xs font-bold text-[#c8872b] uppercase tracking-[0.25em] mb-3 font-sans">Dashboard</h2>
          <h1 className="text-3xl lg:text-4xl font-display text-stone-900 dark:text-stone-100 mb-6">Client Portal</h1>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {quickActions.map((a) => (
              <button key={a.label} className="p-5 bg-white dark:bg-[#292117] rounded-2xl border border-stone-200 dark:border-stone-700/50 shadow-sm hover:shadow-lg hover:border-[#c8872b]/30 transition-all text-left group">
                <div className="w-10 h-10 bg-amber-50 dark:bg-amber-900/15 text-[#c8872b] rounded-xl flex items-center justify-center mb-3 group-hover:bg-[#c8872b] group-hover:text-white transition-colors">
                  <a.icon size={20} />
                </div>
                <div className="font-bold text-sm text-stone-800 dark:text-stone-200">{a.label}</div>
                <div className="text-xs text-stone-500 dark:text-stone-400">{a.desc}</div>
              </button>
            ))}
          </div>
        </div>

        <div className="h-[calc(100vh-380px)] min-h-[500px]">
          <div className="bg-white dark:bg-[#292117] rounded-2xl border border-stone-200 dark:border-stone-700/50 shadow-xl flex h-full overflow-hidden">
            {/* Sidebar */}
            <div className="w-full md:w-80 border-r border-stone-200/60 dark:border-stone-700/50 flex flex-col">
              <div className="p-6 border-b border-stone-200/60 dark:border-stone-700/50">
                <h2 className="text-lg font-display text-stone-900 dark:text-stone-100 mb-4">Messages</h2>
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-stone-400" size={15} />
                  <input type="text" placeholder="Search..." className="w-full pl-9 pr-4 py-2 bg-stone-50 dark:bg-stone-800 border border-stone-200 dark:border-stone-700 rounded-xl text-sm outline-none focus:ring-2 focus:ring-[#c8872b] dark:text-stone-200" />
                </div>
              </div>
              <div className="flex-1 overflow-y-auto">
                {contacts.map((c) => (
                  <button key={c.id} onClick={() => setActiveContact(c)}
                    className={cn("w-full p-4 flex items-center gap-4 hover:bg-stone-50 dark:hover:bg-stone-800/30 transition-colors border-l-[3px]",
                      activeContact.id === c.id ? "bg-amber-50/50 dark:bg-amber-900/10 border-[#c8872b]" : "border-transparent"
                    )}>
                    <div className="relative">
                      <div className="w-11 h-11 bg-stone-100 dark:bg-stone-700 rounded-full flex items-center justify-center text-stone-500 dark:text-stone-400">
                        {c.id === 3 ? <FileText size={18} /> : <User size={20} />}
                      </div>
                      {c.online && <div className="absolute bottom-0 right-0 w-3 h-3 bg-[#5a7a5f] border-2 border-white dark:border-[#292117] rounded-full" />}
                    </div>
                    <div className="flex-1 text-left min-w-0">
                      <div className="flex justify-between items-center mb-1">
                        <span className="font-bold text-stone-800 dark:text-stone-200 truncate text-sm">{c.name}</span>
                        <span className="text-[10px] text-stone-400 font-medium">{c.time}</span>
                      </div>
                      <p className="text-xs text-stone-500 dark:text-stone-400 truncate">{c.lastMsg}</p>
                    </div>
                    {c.unread > 0 && <div className="w-5 h-5 bg-[#c8872b] text-white text-[10px] font-bold rounded-full flex items-center justify-center">{c.unread}</div>}
                  </button>
                ))}
              </div>
            </div>

            {/* Chat */}
            <div className="hidden md:flex flex-1 flex-col bg-[var(--color-brand-cream)]/30 dark:bg-[#1a1612]/30">
              <div className="p-4 bg-white dark:bg-[#292117] border-b border-stone-200/60 dark:border-stone-700/50 flex items-center gap-3">
                <div className="w-10 h-10 bg-amber-50 dark:bg-amber-900/15 rounded-full flex items-center justify-center text-[#c8872b]"><Home size={18} /></div>
                <div>
                  <div className="font-bold text-stone-800 dark:text-stone-200 text-sm">{activeContact.name}</div>
                  <div className={cn("text-[10px] font-bold uppercase tracking-wider", activeContact.online ? "text-[#5a7a5f]" : "text-stone-400")}>{activeContact.online ? 'Online' : 'Offline'}</div>
                </div>
              </div>

              <div className="flex-1 overflow-y-auto p-6 space-y-5">
                <div className="text-center"><span className="px-3 py-1 bg-stone-100 dark:bg-stone-800 rounded-full text-[10px] font-bold text-stone-400 dark:text-stone-500 uppercase tracking-widest">Today</span></div>
                {messages.map((msg) => (
                  <div key={msg.id} className={cn("flex", msg.me ? "justify-end" : "justify-start")}>
                    <div className={cn("max-w-[70%] p-4 rounded-2xl text-sm shadow-sm",
                      msg.me ? "bg-[#c8872b] text-white rounded-tr-none" : "bg-white dark:bg-[#292117] text-stone-700 dark:text-stone-300 rounded-tl-none border border-stone-200/60 dark:border-stone-700/50"
                    )}>
                      <p className="leading-relaxed">{msg.text}</p>
                      <div className={cn("flex items-center gap-1 mt-2 text-[10px]", msg.me ? "text-amber-200/70" : "text-stone-400")}>
                        {msg.time} {msg.me && <CheckCheck size={12} />}
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              <div className="p-5 bg-white dark:bg-[#292117] border-t border-stone-200/60 dark:border-stone-700/50">
                <form onSubmit={(e) => { e.preventDefault(); setMsgInput(''); }} className="flex items-center gap-4">
                  <input type="text" value={msgInput} onChange={(e) => setMsgInput(e.target.value)} placeholder="Type a message..." className="flex-1 px-5 py-3.5 bg-stone-50 dark:bg-stone-800 border border-stone-200 dark:border-stone-700 rounded-xl outline-none focus:ring-2 focus:ring-[#c8872b] transition-all dark:text-stone-200 text-sm" />
                  <button type="submit" className="w-12 h-12 bg-[#c8872b] text-white rounded-xl flex items-center justify-center shadow-lg shadow-amber-900/15 hover:bg-[#b47825] transition-all"><Send size={20} /></button>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
