import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || '' });

export const chatModel = "gemini-3.1-pro-preview";

export async function getChatResponse(messages: { role: 'user' | 'model' | 'system', parts: { text: string }[] }[], systemInstruction?: string) {
  const response = await ai.models.generateContent({
    model: chatModel,
    contents: messages.filter(m => m.role !== 'system'),
    config: {
      systemInstruction: systemInstruction,
      temperature: 0.7,
    },
  });
  return response.text;
}
