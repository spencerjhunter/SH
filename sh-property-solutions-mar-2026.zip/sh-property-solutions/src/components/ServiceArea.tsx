import React from 'react';
import { motion } from 'motion/react';
import { MapPin, Phone, Clock, Wifi } from 'lucide-react';

const towns = [
  { name: 'Midvale', desc: 'Southern anchor of the corridor. Aging housing stock, strong demand for reliable service.', pop: '~200' },
  { name: 'Council', desc: 'Our home base. Physical office on Main Street. HB 768 compliant.', pop: '~830', hq: true },
  { name: 'New Meadows', desc: 'Northern reach. Gateway to McCall. Heavy Snowbird and seasonal-owner demand.', pop: '~500' },
];

export default function ServiceArea() {
  return (
    <section className="py-24 bg-[#1a1612] text-stone-100 relative overflow-hidden grain-overlay">
      <div className="absolute top-0 right-0 w-[40%] h-full bg-gradient-to-l from-[#c8872b]/5 to-transparent" />
      
      <div className="max-w-7xl mx-auto px-6 relative z-10">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Map Visual */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="relative"
          >
            <div className="bg-[#292117] rounded-2xl border border-stone-700/50 p-8 relative overflow-hidden">
              {/* Stylized route */}
              <div className="relative h-80">
                {/* Highway line */}
                <div className="absolute left-1/2 -translate-x-1/2 top-8 bottom-8 w-1 bg-gradient-to-b from-[#c8872b] via-[#c8872b] to-[#c8872b] rounded-full opacity-40" />
                <div className="absolute left-1/2 -translate-x-1/2 top-8 bottom-8 w-[3px] bg-gradient-to-b from-[#c8872b] via-[#c8872b]/80 to-[#c8872b] rounded-full" style={{ backgroundImage: 'repeating-linear-gradient(to bottom, #c8872b 0px, #c8872b 12px, transparent 12px, transparent 24px)' }} />

                {/* Town markers */}
                {[
                  { name: 'New Meadows', top: '8%', side: 'right' },
                  { name: 'Council', top: '45%', side: 'left', hq: true },
                  { name: 'Midvale', top: '82%', side: 'right' },
                ].map((town) => (
                  <div key={town.name} className={`absolute ${town.side === 'left' ? 'right-1/2 mr-6 text-right' : 'left-1/2 ml-6'}`} style={{ top: town.top }}>
                    <div className="flex items-center gap-3" style={{ flexDirection: town.side === 'left' ? 'row-reverse' : 'row' }}>
                      <div className={`w-4 h-4 rounded-full border-[3px] ${town.hq ? 'bg-[#c8872b] border-[#c8872b]/30 shadow-lg shadow-[#c8872b]/40' : 'bg-stone-100 border-stone-400'}`} />
                      <div>
                        <div className="font-display text-sm text-stone-100">{town.name}</div>
                        {town.hq && <div className="text-[9px] font-bold text-[#c8872b] uppercase tracking-wider font-sans">HQ</div>}
                      </div>
                    </div>
                  </div>
                ))}

                {/* Highway label */}
                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 -rotate-90">
                  <div className="px-3 py-1 bg-[#c8872b]/20 rounded-full text-[10px] font-bold text-[#c8872b] uppercase tracking-wider font-sans whitespace-nowrap">
                    Highway 95
                  </div>
                </div>
              </div>
            </div>
          </motion.div>

          {/* Info */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
          >
            <h2 className="text-xs font-bold text-[#c8872b] uppercase tracking-[0.25em] mb-4 font-sans">Coverage</h2>
            <p className="text-4xl lg:text-5xl font-display text-stone-100 mb-6">The Highway 95 Corridor</p>
            <p className="text-stone-400 text-lg leading-relaxed mb-10 font-medium">
              We serve every property from Midvale to New Meadows — and our route optimization batches jobs by town to eliminate dead miles.
            </p>

            <div className="space-y-6 mb-10">
              {towns.map((town) => (
                <div key={town.name} className="flex gap-4">
                  <div className={`w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 ${town.hq ? 'bg-[#c8872b] text-white' : 'bg-stone-800 text-stone-400'}`}>
                    <MapPin size={18} />
                  </div>
                  <div>
                    <div className="font-display text-stone-100 flex items-center gap-2">
                      {town.name}
                      {town.hq && <span className="text-[9px] font-bold font-sans text-[#c8872b] bg-[#c8872b]/15 px-2 py-0.5 rounded-full uppercase tracking-wider">Home Base</span>}
                    </div>
                    <p className="text-stone-400 text-sm mt-1">{town.desc}</p>
                  </div>
                </div>
              ))}
            </div>

            <div className="grid grid-cols-3 gap-4">
              {[
                { icon: Phone, label: '24/7 Emergency', value: '(208) 347-2500' },
                { icon: Clock, label: 'Response Time', value: 'Same-day triage' },
                { icon: Wifi, label: 'Dead Zones', value: 'Offline-ready app' },
              ].map((stat) => (
                <div key={stat.label} className="p-4 bg-stone-800/50 rounded-xl border border-stone-700/50 text-center">
                  <stat.icon size={18} className="text-[#c8872b] mx-auto mb-2" />
                  <div className="text-[10px] text-stone-500 font-bold uppercase tracking-wider font-sans mb-1">{stat.label}</div>
                  <div className="text-xs text-stone-300 font-semibold">{stat.value}</div>
                </div>
              ))}
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
