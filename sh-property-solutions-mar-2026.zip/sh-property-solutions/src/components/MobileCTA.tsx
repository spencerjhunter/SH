import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Phone, Wrench, X } from 'lucide-react';
import { Link, useLocation } from 'react-router-dom';

export default function MobileCTA() {
  const [visible, setVisible] = useState(false);
  const [dismissed, setDismissed] = useState(false);
  const location = useLocation();

  // Hide on onboarding/maintenance pages (they have their own CTAs)
  const hiddenPaths = ['/onboarding', '/maintenance'];
  const isHidden = hiddenPaths.includes(location.pathname);

  useEffect(() => {
    const handleScroll = () => {
      setVisible(window.scrollY > 400);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  if (isHidden || dismissed) return null;

  return (
    <AnimatePresence>
      {visible && (
        <motion.div
          initial={{ y: 100, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          exit={{ y: 100, opacity: 0 }}
          className="fixed bottom-0 left-0 right-0 z-40 lg:hidden"
        >
          <div className="bg-white/95 dark:bg-[#1a1612]/95 backdrop-blur-xl border-t border-stone-200 dark:border-stone-700/50 px-4 py-3 shadow-[0_-4px_20px_rgba(0,0,0,0.08)]">
            <div className="flex items-center gap-3 max-w-lg mx-auto">
              <Link
                to="/maintenance"
                className="flex-1 flex items-center justify-center gap-2 px-4 py-3 bg-[#c8872b] text-white rounded-xl font-bold text-sm shadow-lg shadow-amber-900/15 hover:bg-[#b47825] transition-all"
              >
                <Wrench size={16} />
                Request Service
              </Link>
              <a
                href="tel:2083472500"
                className="flex items-center justify-center gap-2 px-4 py-3 bg-stone-100 dark:bg-stone-800 text-stone-700 dark:text-stone-300 rounded-xl font-bold text-sm hover:bg-stone-200 dark:hover:bg-stone-700 transition-all"
              >
                <Phone size={16} />
                Call
              </a>
              <button
                onClick={() => setDismissed(true)}
                className="p-2 text-stone-400 hover:text-stone-600 dark:hover:text-stone-300 transition-colors"
                aria-label="Dismiss"
              >
                <X size={18} />
              </button>
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
