import React from 'react';
import { motion } from 'motion/react';
import { Star, Quote } from 'lucide-react';

const reviews = [
  { name: 'Karen & Tom W.', role: 'Snowbird Homeowners, New Meadows', content: "We spend winters in Arizona and used to worry constantly about our cabin. The Snowbird plan gives us monthly video check-ins and detailed reports. First time we've had peace of mind being away.", rating: 5, initials: 'KW' },
  { name: 'Jim Halstead', role: 'Tenant, Council', content: "Submitting a maintenance request used to mean calling three times and hoping someone showed up. Now I just submit a ticket online, and it's handled. I actually get updates too — that's a first out here.", rating: 5, initials: 'JH' },
  { name: 'Melissa Park', role: 'Property Owner, Midvale', content: 'The Digital Home Log alone is worth it — I finally know my filter sizes, paint codes, and shut-off locations without driving 3 hours to check. Real "Corporate Grade" service in a rural area.', rating: 5, initials: 'MP' },
];

export default function Reviews() {
  return (
    <section className="py-24 overflow-hidden bg-white dark:bg-[#292117]/50 transition-colors duration-300">
      <div className="max-w-7xl mx-auto px-6">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-6">
          <div>
            <h2 className="text-xs font-bold text-[#c8872b] uppercase tracking-[0.25em] mb-4 font-sans">Testimonials</h2>
            <p className="text-4xl lg:text-5xl font-display text-stone-900 dark:text-stone-100">What Our Clients Say</p>
          </div>
          <div className="flex items-center gap-2 text-stone-500 dark:text-stone-400 font-medium">
            <div className="flex text-[#c8872b]">
              {[...Array(5)].map((_, i) => <Star key={i} size={18} fill="currentColor" />)}
            </div>
            <span className="text-sm">Trusted along Highway 95</span>
          </div>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {reviews.map((review, index) => (
            <motion.div
              key={review.name}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="relative p-8 bg-[var(--color-brand-cream)] dark:bg-[#1a1612] rounded-2xl border border-stone-200/80 dark:border-stone-700/40"
            >
              <Quote className="absolute top-6 right-8 text-[#c8872b]/10" size={60} />
              <div className="flex text-[#c8872b] mb-6">
                {[...Array(review.rating)].map((_, i) => <Star key={i} size={15} fill="currentColor" />)}
              </div>
              <p className="text-stone-600 dark:text-stone-300 mb-8 italic leading-relaxed text-[15px]">"{review.content}"</p>
              <div className="flex items-center gap-4">
                <div className="w-11 h-11 rounded-full bg-[#c8872b]/10 text-[#c8872b] flex items-center justify-center font-display text-lg border border-[#c8872b]/20">
                  {review.initials}
                </div>
                <div>
                  <div className="font-bold text-stone-900 dark:text-stone-100 text-sm">{review.name}</div>
                  <div className="text-xs text-stone-500 dark:text-stone-400 font-medium">{review.role}</div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
