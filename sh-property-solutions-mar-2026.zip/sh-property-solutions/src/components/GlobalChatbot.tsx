import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { MessageCircle, X, Send, Bot, User, Loader2, Minimize2, Maximize2 } from 'lucide-react';
import { getChatResponse } from '@/src/services/gemini';
import { cn } from '@/src/lib/utils';

export default function GlobalChatbot() {
  const [isOpen, setIsOpen] = useState(false);
  const [isMinimized, setIsMinimized] = useState(false);
  const [messages, setMessages] = useState<{ role: 'user' | 'model', text: string }[]>([
    { role: 'model', text: "Hey there! I'm the SH Property Solutions assistant. I can help with service requests, stewardship plans, billing questions, or anything about our Highway 95 corridor coverage. What can I do for you?" }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [messages, isLoading]);

  const handleSend = async (e?: React.FormEvent) => {
    e?.preventDefault();
    if (!input.trim() || isLoading) return;
    const userMessage = input.trim();
    setInput('');
    setMessages(prev => [...prev, { role: 'user', text: userMessage }]);
    setIsLoading(true);
    try {
      const history = messages.map(m => ({ role: m.role, parts: [{ text: m.text }] }));
      history.push({ role: 'user', parts: [{ text: userMessage }] });
      const response = await getChatResponse(history, `You are the AI assistant for SH Property Solutions LLC — a tech-enabled property management and handyman company serving Idaho's Highway 95 corridor (Midvale, Council, New Meadows).

Key facts you should know:
- We serve three core user types: TENANTS (submit requests, pay rent, communicate), SERVICE TECHNICIANS (partner with us for corridor jobs), and LANDLORDS/PROPERTY OWNERS (stewardship plans, property reports).
- We offer 4 Stewardship subscription tiers for landlords: The Retainer ($49/mo), The Snowbird ($75/mo), The Reliability ($125/mo), and The Seasonal ($250+/mo).
- We also do one-off handyman service calls.
- Tenants can submit maintenance requests through our chat intake — issues get triaged, documented with photos, and routed automatically.
- We are Idaho Contractor Registered (2026) with a $1M liability policy.
- Idaho law requires contractor registration for any job over $1,999 — we comply fully.
- Electrical, plumbing, and HVAC work is routed to licensed subcontractor partners (the "Trade Wall").
- Our physical office is in Council, Idaho (HB 768 compliant).
- Every job is documented with before/after photos and detailed reports.
- Our app works offline for dead zones between Midvale and Council.
- We publish a blog ("The Corridor Chronicle") with project showcases, seasonal tips, and videos.

Be professional, friendly, and knowledgeable. Keep answers concise.`);
      if (response) setMessages(prev => [...prev, { role: 'model', text: response }]);
    } catch (error) {
      setMessages(prev => [...prev, { role: 'model', text: "I'm sorry, I'm having trouble connecting right now. Please try again later." }]);
    } finally { setIsLoading(false); }
  };

  return (
    <div className="fixed bottom-6 right-6 z-[100]">
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0, height: isMinimized ? '80px' : '500px' }}
            exit={{ opacity: 0, scale: 0.9, y: 20 }}
            className="mb-4 w-[350px] bg-white dark:bg-[#1a1612] rounded-3xl shadow-2xl border border-stone-200 dark:border-stone-700/50 overflow-hidden flex flex-col transition-all duration-300"
          >
            <div className="p-4 bg-[#c8872b] text-white flex items-center justify-between">
              <div className="flex items-center gap-2">
                <img src="/icon.png" alt="SH" className="w-6 h-6 object-contain rounded-md" onError={(e) => { if (e.currentTarget.src.includes('icon.png')) { e.currentTarget.src = '/icon.svg'; } else { e.currentTarget.src = 'https://placehold.co/100x100/c8872b/white?text=Icon'; } }} />
                <span className="font-bold text-sm">SH Assistant</span>
              </div>
              <div className="flex items-center gap-1">
                <button onClick={() => setIsMinimized(!isMinimized)} className="p-1 hover:bg-white/10 rounded-lg transition-colors">
                  {isMinimized ? <Maximize2 size={14} /> : <Minimize2 size={14} />}
                </button>
                <button onClick={() => setIsOpen(false)} className="p-1 hover:bg-white/10 rounded-lg transition-colors">
                  <X size={14} />
                </button>
              </div>
            </div>
            {!isMinimized && (
              <>
                <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-4 bg-[var(--color-brand-cream)] dark:bg-[#292117]/50">
                  {messages.map((msg, i) => (
                    <div key={i} className={cn("flex", msg.role === 'user' ? "justify-end" : "justify-start")}>
                      <div className={cn("max-w-[85%] p-3 rounded-2xl text-xs shadow-sm", msg.role === 'user'
                        ? "bg-[#c8872b] text-white rounded-tr-none"
                        : "bg-white dark:bg-[#1a1612] text-stone-700 dark:text-stone-300 rounded-tl-none border border-stone-200 dark:border-stone-700/50"
                      )}>{msg.text}</div>
                    </div>
                  ))}
                  {isLoading && (
                    <div className="flex justify-start">
                      <div className="bg-white dark:bg-[#1a1612] border border-stone-200 dark:border-stone-700/50 p-3 rounded-2xl rounded-tl-none shadow-sm">
                        <Loader2 size={12} className="animate-spin text-[#c8872b]" />
                      </div>
                    </div>
                  )}
                </div>
                <div className="p-3 bg-white dark:bg-[#1a1612] border-t border-stone-200 dark:border-stone-700/50">
                  <form onSubmit={handleSend} className="flex items-center gap-2">
                    <input type="text" value={input} onChange={(e) => setInput(e.target.value)} placeholder="Ask a question..." className="flex-1 px-4 py-2 bg-stone-50 dark:bg-[#292117] border border-stone-200 dark:border-stone-700 rounded-xl outline-none focus:ring-2 focus:ring-[#c8872b] text-xs dark:text-stone-200" />
                    <button type="submit" disabled={!input.trim() || isLoading} className="w-10 h-10 bg-[#c8872b] text-white rounded-xl flex items-center justify-center shadow-lg shadow-amber-900/20 hover:bg-[#b47825] transition-all disabled:opacity-50">
                      <Send size={14} />
                    </button>
                  </form>
                </div>
              </>
            )}
          </motion.div>
        )}
      </AnimatePresence>
      <motion.button whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }} onClick={() => setIsOpen(!isOpen)}
        className={cn("w-14 h-14 rounded-full flex items-center justify-center shadow-2xl transition-all duration-300",
          isOpen ? "bg-white dark:bg-stone-800 text-[#c8872b] border border-stone-200 dark:border-stone-700" : "bg-[#c8872b] text-white"
        )}
      >
        {isOpen ? <X size={28} /> : <MessageCircle size={28} />}
      </motion.button>
    </div>
  );
}
