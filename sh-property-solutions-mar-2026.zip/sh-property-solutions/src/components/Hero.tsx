import React from 'react';
import { motion } from 'motion/react';
import { ArrowRight, Shield, Wifi, MapPin, CheckCircle2 } from 'lucide-react';
import { Link } from 'react-router-dom';

const trustItems = [
  'Idaho Licensed',
  '$1M Insured',
  'Background-Checked',
  'Offline-Ready',
];

export default function Hero() {
  return (
    <section className="relative pt-32 pb-20 lg:pt-44 lg:pb-32 overflow-hidden">
      {/* Warm ambient backgrounds */}
      <div className="absolute inset-0 -z-10">
        <div className="absolute top-[-15%] left-[-10%] w-[50%] h-[50%] bg-amber-100/30 dark:bg-amber-900/5 rounded-full blur-[100px]" />
        <div className="absolute bottom-[-15%] right-[-10%] w-[45%] h-[45%] bg-[#e8efe9] dark:bg-emerald-900/5 rounded-full blur-[100px]" />
      </div>

      <div className="max-w-7xl mx-auto px-6">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7 }}
          >
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-[#e8efe9] dark:bg-[#5a7a5f]/20 text-[#5a7a5f] dark:text-[#8ab08f] rounded-full text-xs font-bold uppercase tracking-[0.15em] mb-8 border border-[#5a7a5f]/20">
              <MapPin size={14} />
              Midvale &middot; Council &middot; New Meadows
            </div>

            <h1 className="text-5xl lg:text-[4.25rem] xl:text-7xl font-display text-stone-900 dark:text-stone-100 mb-6 leading-[1.05] tracking-tight">
              Your Property's
              <br />
              <span className="text-[#c8872b]">Dedicated Steward.</span>
            </h1>

            <p className="text-lg text-stone-600 dark:text-stone-400 mb-10 max-w-lg leading-relaxed font-medium">
              Corporate-grade reliability with a country touch. Diligent maintenance, seasonal protection, and transparent reporting for tenants, landlords, and service professionals along the Highway&nbsp;95 corridor.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 mb-12">
              <Link
                to="/maintenance"
                className="inline-flex items-center justify-center gap-2 px-8 py-4 bg-[#c8872b] text-white rounded-2xl font-bold shadow-xl shadow-amber-900/15 hover:bg-[#b47825] transition-all hover:-translate-y-0.5"
              >
                Submit a Request
                <ArrowRight size={20} />
              </Link>
              <Link
                to="/onboarding"
                className="inline-flex items-center justify-center px-8 py-4 bg-white dark:bg-stone-900 text-stone-800 dark:text-stone-200 border-2 border-stone-200 dark:border-stone-700 rounded-2xl font-bold hover:border-[#c8872b] hover:text-[#c8872b] transition-all"
              >
                Explore Plans
              </Link>
            </div>

            {/* Trust Bar */}
            <div className="flex flex-wrap items-center gap-x-5 gap-y-2">
              {trustItems.map((item) => (
                <div key={item} className="flex items-center gap-1.5 text-sm text-stone-500 dark:text-stone-400 font-medium">
                  <CheckCircle2 size={15} className="text-[#5a7a5f]" />
                  {item}
                </div>
              ))}
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.92 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.7, delay: 0.15 }}
            className="relative"
          >
            <div className="relative rounded-3xl overflow-hidden shadow-2xl shadow-stone-900/20 border-[6px] border-white dark:border-stone-800">
              <img
                src="/banner.png"
                alt="SH Property Solutions Banner"
                className="w-full h-full object-cover aspect-[16/9]"
                onError={(e) => {
                  if (e.currentTarget.src.includes('banner.png')) {
                    e.currentTarget.src = '/banner.svg';
                  } else {
                    e.currentTarget.src = "https://placehold.co/1200x675/1a1612/c8872b?text=Upload+banner.png+to+/public";
                  }
                }}
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#1a1612]/60 via-transparent to-transparent" />

              {/* Floating Stats */}
              <div className="absolute bottom-5 left-5 right-5 p-5 bg-white/92 dark:bg-[#1a1612]/92 backdrop-blur-lg rounded-2xl border border-white/30 dark:border-stone-700/30 shadow-xl">
                <div className="flex justify-between items-center">
                  <div className="text-center">
                    <div className="text-xl font-display text-stone-900 dark:text-stone-100">Hwy 95</div>
                    <div className="text-[10px] text-stone-500 dark:text-stone-400 uppercase tracking-wider font-bold mt-0.5">Full Corridor</div>
                  </div>
                  <div className="h-8 w-[1px] bg-stone-200 dark:bg-stone-700" />
                  <div className="text-center">
                    <div className="text-xl font-display text-stone-900 dark:text-stone-100">24/7</div>
                    <div className="text-[10px] text-stone-500 dark:text-stone-400 uppercase tracking-wider font-bold mt-0.5">Emergency</div>
                  </div>
                  <div className="h-8 w-[1px] bg-stone-200 dark:bg-stone-700" />
                  <div className="text-center">
                    <div className="text-xl font-display text-[#c8872b]">Detailed</div>
                    <div className="text-[10px] text-stone-500 dark:text-stone-400 uppercase tracking-wider font-bold mt-0.5">Reporting</div>
                  </div>
                </div>
              </div>
            </div>

            {/* Decorative accent */}
            <div className="absolute -bottom-4 -right-4 w-24 h-24 bg-[#c8872b]/10 rounded-2xl -z-10" />
            <div className="absolute -top-4 -left-4 w-16 h-16 bg-[#5a7a5f]/10 rounded-2xl -z-10" />
          </motion.div>
        </div>
      </div>
    </section>
  );
}
