import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Plus, Minus, HelpCircle } from 'lucide-react';

const faqs = [
  { question: "I'm a tenant — how do I submit a maintenance request?", answer: 'Just click "Submit a Request" from the homepage or go to the Service page. Our intake system will walk you through it in a quick chat — describe the issue, pick the priority, and we\'ll handle the rest. You\'ll get updates and can track progress right from your portal.' },
  { question: 'What areas do you serve along the Highway 95 corridor?', answer: 'We provide full property maintenance and management services from Midvale through Council and up to New Meadows. Our route optimization system batches jobs by town to eliminate "dead miles," so we can offer reliable scheduling even in the most remote areas of the corridor.' },
  { question: 'How does the subscription model work for landlords?', answer: 'Instead of hunting for a contractor when something breaks, our Stewardship plans guarantee availability. Choose from four tiers — The Retainer ($49/mo), The Snowbird ($75/mo), The Reliability ($125/mo), or The Seasonal ($250+/mo) — and get priority scheduling, detailed property reports, and peace of mind year-round.' },
  { question: "I'm a \"Snowbird\" — can you watch my property while I'm away?", answer: "Absolutely. Our Snowbird plan ($75/mo) includes monthly visual walkthroughs with 360° video stored in your private Video Vault. You'll receive comprehensive condition reports so you can check on your property from anywhere." },
  { question: "I'm a service technician — how do I partner with SH Property Solutions?", answer: 'We\'re always looking for reliable, licensed trade professionals along the corridor. Our "Trade Wall" system routes electrical, plumbing, and HVAC work to vetted partners. Get started through our onboarding page and we\'ll connect you with our team.' },
  { question: "What's the $2,000 rule I've heard about?", answer: 'Idaho law requires contractor registration for any job over $1,999. Our app automatically flags any quote approaching that threshold to ensure full compliance. We hold a 2026 Idaho Contractor Registration and carry a $1M liability policy for your protection.' },
  { question: 'Are your technicians licensed and insured?', answer: 'Yes. We are Idaho Contractor Registered with a $1M liability policy. For specialized trade work (electrical, plumbing, HVAC), our "Trade Wall" system automatically routes to fully licensed subcontractor partners — everything is above board and documented.' },
];

export default function FAQ() {
  const [activeIndex, setActiveIndex] = useState<number | null>(0);

  return (
    <section className="py-24 bg-[#5a7a5f] text-white overflow-hidden relative grain-overlay">
      <div className="absolute top-[-10%] right-[-10%] w-[40%] h-[40%] bg-white/5 rounded-full blur-[100px]" />
      <div className="absolute bottom-[-10%] left-[-10%] w-[40%] h-[40%] bg-white/5 rounded-full blur-[100px]" />

      <div className="max-w-4xl mx-auto px-6 relative z-10">
        <div className="text-center mb-16">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-white/10 rounded-2xl mb-6 backdrop-blur-md">
            <HelpCircle size={32} className="text-white/80" />
          </div>
          <h2 className="text-xs font-bold text-white/60 uppercase tracking-[0.25em] mb-4 font-sans">Support Center</h2>
          <p className="text-4xl lg:text-5xl font-display mb-4">Frequently Asked Questions</p>
          <p className="text-white/60 font-medium">For tenants, landlords, and service professionals.</p>
        </div>

        <div className="space-y-3">
          {faqs.map((faq, index) => (
            <div key={index} className="bg-white/10 backdrop-blur-md border border-white/10 rounded-2xl overflow-hidden transition-all hover:bg-white/20">
              <button onClick={() => setActiveIndex(activeIndex === index ? null : index)} className="w-full px-7 py-5 flex items-center justify-between text-left">
                <span className="text-[15px] font-semibold font-sans pr-4">{faq.question}</span>
                <div className="flex-shrink-0">{activeIndex === index ? <Minus size={18} /> : <Plus size={18} />}</div>
              </button>
              <AnimatePresence>
                {activeIndex === index && (
                  <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }} transition={{ duration: 0.3 }}>
                    <div className="px-7 pb-5 text-white/70 leading-relaxed text-sm">{faq.answer}</div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          ))}
        </div>

        <div className="mt-16 p-8 bg-white/10 backdrop-blur-md rounded-3xl border border-white/10 text-center">
          <p className="text-lg font-display mb-3">Still have questions?</p>
          <p className="text-white/60 mb-6 text-sm">Reach out directly or use the chat assistant.</p>
          <a href="tel:2083472500" className="px-8 py-3.5 bg-white text-[#5a7a5f] rounded-xl font-bold hover:bg-white/90 transition-all inline-block text-sm">
            Call (208) 347-2500
          </a>
        </div>
      </div>
    </section>
  );
}
