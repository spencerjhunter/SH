import React from 'react';
import { motion } from 'motion/react';
import { Calendar, Camera, Cpu, Leaf, CheckCircle2, ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';

const tiers = [
  { name: 'The Retainer', price: 49, focus: 'Priority Booking & 2x Annual Visits', icon: Calendar, features: ['Priority scheduling during busy season', '2 annual property check-ins', 'Automated scheduling & reminders', 'Digital Home Log access'], popular: false },
  { name: 'The Snowbird', price: 75, focus: 'Monthly visual checks for remote owners', icon: Camera, features: ['Everything in The Retainer', 'Monthly property walkthroughs', '360° Video Vault access', 'Detailed condition reports'], popular: true },
  { name: 'The Reliability', price: 125, focus: 'Generator / Well / Septic / Solar monitoring', icon: Cpu, features: ['Everything in The Snowbird', 'IoT sensor integration', 'Real-time system alerts', 'Preventative maintenance scheduling'], popular: false },
  { name: 'The Seasonal', price: 250, focus: 'Flat-fee Spring/Fall 20-Point Checklists', icon: Leaf, features: ['Everything in The Reliability', 'Full 20-point seasonal inspections', 'Comprehensive Property Health Report', 'Priority emergency response'], popular: false },
];

export default function Pricing() {
  return (
    <section className="py-24 bg-[var(--color-brand-cream)] dark:bg-[#1a1612] transition-colors duration-300">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-xs font-bold text-[#c8872b] uppercase tracking-[0.25em] mb-4 font-sans">Stewardship Plans</h2>
          <p className="text-4xl lg:text-5xl font-display text-stone-900 dark:text-stone-100 mb-4">Reliability as a Subscription</p>
          <p className="text-stone-500 dark:text-stone-400 max-w-2xl mx-auto font-medium">
            Never hunt for a contractor during the busy season again. Choose the plan that fits your property's needs.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {tiers.map((tier, index) => (
            <motion.div
              key={tier.name}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className={`relative p-7 bg-white dark:bg-[#292117] rounded-2xl border-2 shadow-sm flex flex-col transition-all hover:shadow-xl ${tier.popular
                  ? 'border-[#c8872b] ring-1 ring-[#c8872b]/20'
                  : 'border-stone-200 dark:border-stone-700/50'
                }`}
            >
              {tier.popular && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-4 py-1 bg-[#c8872b] text-white text-[10px] font-bold uppercase tracking-wider rounded-full font-sans">
                  Popular
                </div>
              )}

              <div className="w-11 h-11 bg-amber-50 dark:bg-amber-900/15 text-[#c8872b] rounded-xl flex items-center justify-center mb-4">
                <tier.icon size={22} />
              </div>

              <h3 className="text-lg font-display text-stone-900 dark:text-stone-100 mb-1">{tier.name}</h3>
              <p className="text-xs text-stone-500 dark:text-stone-400 mb-4">{tier.focus}</p>

              <div className="flex items-baseline gap-1 mb-6">
                <span className="text-4xl font-display text-stone-900 dark:text-stone-100">${tier.price}</span>
                <span className="text-sm text-stone-400">/mo</span>
              </div>

              <ul className="space-y-3 mb-8 flex-1">
                {tier.features.map((f) => (
                  <li key={f} className="flex items-start gap-2 text-sm text-stone-600 dark:text-stone-400">
                    <CheckCircle2 size={15} className="text-[#5a7a5f] mt-0.5 flex-shrink-0" />
                    {f}
                  </li>
                ))}
              </ul>

              <Link
                to="/onboarding"
                className={`w-full inline-flex items-center justify-center gap-2 px-6 py-3 rounded-xl font-bold transition-all text-sm ${tier.popular
                    ? 'bg-[#c8872b] text-white hover:bg-[#b47825] shadow-lg shadow-amber-900/15'
                    : 'bg-stone-100 dark:bg-stone-800 text-stone-800 dark:text-stone-200 hover:bg-stone-200 dark:hover:bg-stone-700'
                  }`}
              >
                Get Started <ArrowRight size={15} />
              </Link>
            </motion.div>
          ))}
        </div>

        <div className="mt-12 text-center">
          <p className="text-sm text-stone-500 dark:text-stone-400">
            All plans include Client Portal access, detailed property reports, and before/after photo documentation.
            <br />
            <span className="font-semibold text-stone-700 dark:text-stone-300">Need something custom?</span> We offer one-off service calls too — just submit a request.
          </p>
        </div>
      </div>
    </section>
  );
}
