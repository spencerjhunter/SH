import React from 'react';
import { Link } from 'react-router-dom';
import { Facebook, Instagram, Youtube, Mail, Phone, MapPin } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-[#1a1612] text-stone-400 pt-20 pb-10">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
          <div>
            <Link to="/" className="flex items-center gap-2.5 mb-6 group">
              <img 
                src="/logo.png" 
                alt="SH Property Solutions" 
                className="h-32 object-contain rounded-xl"
                onError={(e) => {
                  if (e.currentTarget.src.includes('logo.png')) {
                    e.currentTarget.src = '/logo.svg';
                  } else {
                    e.currentTarget.src = 'https://placehold.co/400x150/c8872b/white?text=Upload+logo.png';
                  }
                }}
              />
            </Link>
            <p className="text-sm leading-relaxed mb-8 text-stone-500">
              Tech-enabled property management and handyman services for the Highway 95 corridor. Corporate-grade reliability with a country touch.
            </p>
            <div className="flex gap-3">
              {[Facebook, Instagram, Youtube].map((Icon, i) => (
                <a key={i} href="#" className="w-9 h-9 rounded-full bg-stone-800 flex items-center justify-center hover:bg-[#c8872b] hover:text-white transition-all text-stone-500">
                  <Icon size={16} />
                </a>
              ))}
            </div>
          </div>

          <div>
            <h4 className="text-stone-200 font-bold mb-6 text-sm font-sans">Quick Links</h4>
            <ul className="space-y-3.5 text-sm">
              {[['/', 'Home'], ['/maintenance', 'Submit a Request'], ['/communication', 'Client Portal'], ['/billing', 'Stewardship Plans'], ['/blog', 'Blog & Videos'], ['/onboarding', 'Get Started']].map(([to, label]) => (
                <li key={to}><Link to={to} className="hover:text-[#c8872b] transition-colors">{label}</Link></li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="text-stone-200 font-bold mb-6 text-sm font-sans">Services</h4>
            <ul className="space-y-3.5 text-sm">
              {['Maintenance Requests', 'Seasonal Inspections', 'Snowbird Property Watch', 'Smart Home & IoT', 'General Handyman', 'Licensed Trade Referrals'].map(s => (
                <li key={s}><span className="hover:text-[#c8872b] transition-colors cursor-pointer">{s}</span></li>
              ))}
            </ul>
            <h4 className="text-stone-200 font-bold mb-4 mt-8 text-sm font-sans">Service Areas</h4>
            <ul className="space-y-3.5 text-sm">
              {[['new-meadows', 'New Meadows'], ['council', 'Council'], ['midvale', 'Midvale']].map(([slug, name]) => (
                <li key={slug}><Link to={`/services/${slug}`} className="hover:text-[#c8872b] transition-colors">{name}, Idaho</Link></li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="text-stone-200 font-bold mb-6 text-sm font-sans">Contact Us</h4>
            <ul className="space-y-4 text-sm">
              <li className="flex items-start gap-3"><MapPin size={16} className="text-[#c8872b] flex-shrink-0 mt-0.5" /><span>Main Street<br />Council, Idaho 83612</span></li>
              <li className="flex items-center gap-3"><Phone size={16} className="text-[#c8872b] flex-shrink-0" /><a href="tel:2083472500" className="hover:text-[#c8872b] transition-colors">(208) 347-2500</a></li>
              <li className="flex items-center gap-3"><Mail size={16} className="text-[#c8872b] flex-shrink-0" /><span>hello@shpropertysolutions.com</span></li>
            </ul>
          </div>
        </div>

        <div className="pt-8 border-t border-stone-800 flex flex-col md:flex-row justify-between items-center gap-4 text-[10px] text-stone-600 uppercase tracking-widest font-bold">
          <p>&copy; 2026 SH Property Solutions LLC &middot; Council, Idaho &middot; Idaho Contractor Reg. 2026</p>
          <div className="flex gap-8">
            <a href="#" className="hover:text-stone-300 transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-stone-300 transition-colors">Terms of Service</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
