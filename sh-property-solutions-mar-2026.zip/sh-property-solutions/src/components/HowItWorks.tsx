import React from 'react';
import { motion } from 'motion/react';
import { MessageSquare, ClipboardCheck, ThumbsUp } from 'lucide-react';

const steps = [
  {
    num: '01',
    icon: MessageSquare,
    title: 'Tell Us What You Need',
    description: 'Submit a request through our intake portal — describe the issue, pick the priority, and we handle the rest. Tenants, landlords, and service pros all start here.',
  },
  {
    num: '02',
    icon: ClipboardCheck,
    title: 'We Triage & Schedule',
    description: 'Our system routes your request to the right technician, generates a quote, and locks in a time that works. Trade work goes through our licensed subcontractor network automatically.',
  },
  {
    num: '03',
    icon: ThumbsUp,
    title: 'Done, Documented, Done',
    description: 'Every job is completed with before/after photos and a detailed completion summary. Your Digital Home Log updates automatically. No surprises, no mystery invoices.',
  },
];

export default function HowItWorks() {
  return (
    <section className="py-24 bg-[#1a1612] text-stone-100 relative overflow-hidden grain-overlay">
      {/* Warm ambient glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[60%] h-[60%] bg-[#c8872b]/5 rounded-full blur-[120px]" />

      <div className="max-w-7xl mx-auto px-6 relative z-10">
        <div className="text-center mb-20">
          <h2 className="text-xs font-bold text-[#c8872b] uppercase tracking-[0.25em] mb-4 font-sans">How It Works</h2>
          <p className="text-4xl lg:text-5xl font-display text-stone-100 mb-4">Three Steps to Peace of Mind</p>
          <p className="text-stone-400 max-w-xl mx-auto font-medium">
            Whether you're a tenant reporting a leak or a snowbird checking on your cabin — the process is the same.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 lg:gap-12">
          {steps.map((step, index) => (
            <motion.div
              key={step.num}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.15 }}
              className="relative text-center group"
            >
              {/* Connector line */}
              {index < steps.length - 1 && (
                <div className="hidden md:block absolute top-12 left-[60%] w-[80%] h-[1px] bg-gradient-to-r from-stone-700 to-transparent" />
              )}

              <div className="relative inline-flex items-center justify-center w-24 h-24 mb-8">
                <div className="absolute inset-0 rounded-2xl bg-[#c8872b]/10 border border-[#c8872b]/20 rotate-3 group-hover:rotate-6 transition-transform" />
                <div className="relative w-full h-full rounded-2xl bg-[#292117] border border-stone-700/50 flex items-center justify-center">
                  <step.icon size={36} className="text-[#c8872b]" />
                </div>
                <div className="absolute -top-2 -right-2 w-8 h-8 rounded-full bg-[#c8872b] text-white text-xs font-bold flex items-center justify-center font-sans shadow-lg">
                  {step.num}
                </div>
              </div>

              <h3 className="text-xl font-display text-stone-100 mb-3">{step.title}</h3>
              <p className="text-stone-400 text-sm leading-relaxed max-w-xs mx-auto">
                {step.description}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
