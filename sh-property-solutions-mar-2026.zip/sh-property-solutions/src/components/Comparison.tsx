import React from 'react';
import { motion } from 'motion/react';
import { X, Check } from 'lucide-react';

const rows = [
  { feature: 'Submit maintenance requests anytime', without: false, with: true },
  { feature: 'Detailed property reports with photos', without: false, with: true },
  { feature: 'Licensed & insured service guarantee', without: false, with: true },
  { feature: 'Know your filter sizes, paint codes & shut-offs', without: false, with: true },
  { feature: '360° video walkthroughs for remote owners', without: false, with: true },
  { feature: 'Automatic routing to licensed trade pros', without: false, with: true },
  { feature: 'Transparent pricing — no surprise invoices', without: false, with: true },
  { feature: 'Calling around, hoping someone answers', without: true, with: false },
  { feature: 'Driving 3 hours to check on your cabin', without: true, with: false },
  { feature: 'No documentation, no receipts, no records', without: true, with: false },
];

export default function Comparison() {
  return (
    <section className="py-24 bg-[var(--color-brand-cream)] dark:bg-[#1a1612] transition-colors duration-300">
      <div className="max-w-4xl mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-xs font-bold text-[#c8872b] uppercase tracking-[0.25em] mb-4 font-sans">Why It Matters</h2>
          <p className="text-4xl lg:text-5xl font-display text-stone-900 dark:text-stone-100 mb-4">The Difference Is Clear</p>
          <p className="text-stone-500 dark:text-stone-400 max-w-xl mx-auto font-medium">
            Property care on the Highway 95 corridor before and after SH Property Solutions.
          </p>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="bg-white dark:bg-[#292117] rounded-3xl border border-stone-200 dark:border-stone-700/50 shadow-xl overflow-hidden"
        >
          {/* Header */}
          <div className="grid grid-cols-[1fr_100px_100px] sm:grid-cols-[1fr_140px_140px] border-b border-stone-200 dark:border-stone-700/50">
            <div className="p-5" />
            <div className="p-5 text-center bg-stone-100 dark:bg-stone-800/50 border-x border-stone-200 dark:border-stone-700/50">
              <div className="text-xs font-bold text-stone-400 dark:text-stone-500 uppercase tracking-wider font-sans">Without SH</div>
            </div>
            <div className="p-5 text-center bg-[#c8872b]/10">
              <div className="text-xs font-bold text-[#c8872b] uppercase tracking-wider font-sans">With SH</div>
            </div>
          </div>

          {/* Rows */}
          {rows.map((row, i) => (
            <div
              key={i}
              className="grid grid-cols-[1fr_100px_100px] sm:grid-cols-[1fr_140px_140px] border-b border-stone-100 dark:border-stone-800/50 last:border-0 hover:bg-stone-50 dark:hover:bg-stone-800/20 transition-colors"
            >
              <div className="p-4 sm:p-5 text-sm text-stone-700 dark:text-stone-300 font-medium flex items-center">
                {row.feature}
              </div>
              <div className="p-4 sm:p-5 flex items-center justify-center border-x border-stone-100 dark:border-stone-800/50 bg-stone-50/50 dark:bg-stone-800/20">
                {row.without ? (
                  <div className="w-7 h-7 rounded-full bg-rose-100 dark:bg-rose-900/30 text-rose-500 flex items-center justify-center">
                    <Check size={14} />
                  </div>
                ) : (
                  <div className="w-7 h-7 rounded-full bg-stone-100 dark:bg-stone-700 text-stone-400 dark:text-stone-500 flex items-center justify-center">
                    <X size={14} />
                  </div>
                )}
              </div>
              <div className="p-4 sm:p-5 flex items-center justify-center bg-[#c8872b]/[0.03]">
                {row.with ? (
                  <div className="w-7 h-7 rounded-full bg-[#5a7a5f]/15 text-[#5a7a5f] flex items-center justify-center">
                    <Check size={14} strokeWidth={3} />
                  </div>
                ) : (
                  <div className="w-7 h-7 rounded-full bg-stone-100 dark:bg-stone-700 text-stone-400 dark:text-stone-500 flex items-center justify-center">
                    <X size={14} />
                  </div>
                )}
              </div>
            </div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
