import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { motion, AnimatePresence } from 'motion/react';
import { Menu, X, Home, Users, Wrench, CreditCard, MessageSquare, Sun, Moon, BookOpen, Phone } from 'lucide-react';
import { cn } from '@/src/lib/utils';
import { useTheme } from '@/src/context/ThemeContext';

const navItems = [
  { name: 'Home', path: '/', icon: Home },
  { name: 'Service', path: '/maintenance', icon: Wrench },
  { name: 'Portal', path: '/communication', icon: MessageSquare },
  { name: 'Plans', path: '/billing', icon: CreditCard },
  { name: 'Blog', path: '/blog', icon: BookOpen },
  { name: 'Get Started', path: '/onboarding', icon: Users },
];

export default function Navbar() {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const location = useLocation();
  const { theme, toggleTheme } = useTheme();

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <nav
      className={cn(
        'fixed top-4 left-1/2 -translate-x-1/2 z-50 w-[95%] max-w-7xl transition-all duration-500 ease-in-out',
        'rounded-2xl border shadow-2xl backdrop-blur-xl',
        scrolled
          ? 'bg-white/80 dark:bg-[#1a1612]/80 border-stone-200/50 dark:border-stone-700/30 py-2'
          : 'bg-white/50 dark:bg-[#1a1612]/50 border-stone-200/30 dark:border-stone-700/20 py-4'
      )}
    >
      <div className="px-6 flex items-center justify-between">
        <Link to="/" className="flex items-center gap-2.5 group">
          <img 
            src="/icon.png" 
            alt="SH" 
            className="h-10 w-10 object-contain transition-transform group-hover:scale-110 rounded-md"
            onError={(e) => {
              if (e.currentTarget.src.includes('icon.png')) {
                e.currentTarget.src = '/icon.svg';
              } else {
                e.currentTarget.src = 'https://placehold.co/100x100/c8872b/white?text=Icon';
              }
            }}
          />
          <div className="hidden sm:block">
            <span className="font-display text-lg text-stone-900 dark:text-stone-100 block leading-tight">
              Property Solutions
            </span>
            <span className="text-[9px] font-sans font-bold text-[#5a7a5f] dark:text-[#8ab08f] uppercase tracking-[0.2em]">Highway 95 Corridor</span>
          </div>
        </Link>

        {/* Desktop Nav */}
        <div className="hidden lg:flex items-center gap-1">
          {navItems.map((item) => {
            const isActive = location.pathname === item.path;
            return (
              <Link
                key={item.path}
                to={item.path}
                className={cn(
                  'px-3.5 py-2 rounded-xl text-sm font-semibold transition-all duration-200 flex items-center gap-2',
                  isActive
                    ? 'bg-[#c8872b] text-white shadow-lg shadow-amber-900/20'
                    : 'text-stone-600 dark:text-stone-400 hover:bg-stone-100/60 dark:hover:bg-stone-800/40 hover:text-[#c8872b]'
                )}
              >
                <item.icon size={15} />
                {item.name}
              </Link>
            );
          })}
          
          <div className="w-[1px] h-6 bg-stone-200 dark:bg-stone-700 mx-2" />

          <a href="tel:2083472500" className="flex items-center gap-1.5 px-3 py-2 text-sm font-bold text-[#c8872b] hover:bg-amber-50 dark:hover:bg-amber-900/10 rounded-xl transition-all">
            <Phone size={14} />
            <span className="hidden xl:inline">(208) 347-2500</span>
          </a>
          
          <button
            onClick={toggleTheme}
            className="p-2 text-stone-500 dark:text-stone-400 hover:bg-stone-100/60 dark:hover:bg-stone-800/40 rounded-xl transition-all"
            aria-label="Toggle theme"
          >
            {theme === 'light' ? <Moon size={18} /> : <Sun size={18} />}
          </button>
        </div>

        {/* Mobile */}
        <div className="flex items-center gap-2 lg:hidden">
          <a href="tel:2083472500" className="p-2 text-[#c8872b]">
            <Phone size={20} />
          </a>
          <button onClick={toggleTheme} className="p-2 text-stone-500 dark:text-stone-400 rounded-xl">
            {theme === 'light' ? <Moon size={20} /> : <Sun size={20} />}
          </button>
          <button onClick={() => setIsOpen(!isOpen)} className="p-2 text-stone-600 dark:text-stone-400 rounded-xl">
            {isOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="lg:hidden absolute top-full left-0 right-0 mt-2 p-4 bg-white/95 dark:bg-[#1a1612]/95 backdrop-blur-2xl rounded-2xl border border-stone-200/50 dark:border-stone-700/30 shadow-2xl mx-2"
          >
            <div className="flex flex-col gap-2">
              {navItems.map((item) => {
                const isActive = location.pathname === item.path;
                return (
                  <Link
                    key={item.path}
                    to={item.path}
                    onClick={() => setIsOpen(false)}
                    className={cn(
                      'px-4 py-3 rounded-xl text-base font-medium flex items-center gap-3 transition-all',
                      isActive
                        ? 'bg-[#c8872b] text-white'
                        : 'text-stone-600 dark:text-stone-300 hover:bg-stone-100 dark:hover:bg-stone-800'
                    )}
                  >
                    <item.icon size={20} />
                    {item.name}
                  </Link>
                );
              })}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
}
