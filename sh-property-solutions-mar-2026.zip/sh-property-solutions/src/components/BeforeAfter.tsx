import React, { useState, useRef, useCallback } from 'react';
import { motion } from 'motion/react';
import { ArrowLeftRight } from 'lucide-react';

interface Project {
  title: string;
  location: string;
  description: string;
  before: string;
  after: string;
}

const projects: Project[] = [
  {
    title: 'Deck Restoration',
    location: 'Council, ID',
    description: 'Five years of Idaho weather had taken its toll. Full sand, stain, and seal — completed in two days.',
    before: 'https://images.unsplash.com/photo-1591825729269-caeb344f6df2?auto=format&fit=crop&q=80&w=700',
    after: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&q=80&w=700',
  },
  {
    title: 'Kitchen Cabinet Refresh',
    location: 'New Meadows, ID',
    description: 'Outdated oak cabinets repainted, new hardware installed, and backsplash replaced. Total cost under $1,800.',
    before: 'https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?auto=format&fit=crop&q=80&w=700',
    after: 'https://images.unsplash.com/photo-1556909172-54557c7e4fb7?auto=format&fit=crop&q=80&w=700',
  },
  {
    title: 'Exterior Paint & Trim',
    location: 'Midvale, ID',
    description: 'Full exterior repaint on a 1972 ranch home. Prep, prime, two coats. Rot repair on south-facing trim.',
    before: 'https://images.unsplash.com/photo-1570129477492-45c003edd2be?auto=format&fit=crop&q=80&w=700',
    after: 'https://images.unsplash.com/photo-1564013799919-ab600027ffc6?auto=format&fit=crop&q=80&w=700',
  },
];

function Slider({ project }: { project: Project }) {
  const [position, setPosition] = useState(50);
  const containerRef = useRef<HTMLDivElement>(null);
  const isDragging = useRef(false);

  const updatePosition = useCallback((clientX: number) => {
    if (!containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const x = Math.max(0, Math.min(clientX - rect.left, rect.width));
    setPosition((x / rect.width) * 100);
  }, []);

  const handlePointerDown = (e: React.PointerEvent) => {
    isDragging.current = true;
    (e.target as HTMLElement).setPointerCapture(e.pointerId);
    updatePosition(e.clientX);
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    if (!isDragging.current) return;
    updatePosition(e.clientX);
  };

  const handlePointerUp = () => { isDragging.current = false; };

  return (
    <div
      ref={containerRef}
      className="relative w-full aspect-[3/2] rounded-2xl overflow-hidden cursor-col-resize select-none shadow-lg"
      onPointerDown={handlePointerDown}
      onPointerMove={handlePointerMove}
      onPointerUp={handlePointerUp}
    >
      {/* After (full background) */}
      <img src={project.after} alt="After" className="absolute inset-0 w-full h-full object-cover" referrerPolicy="no-referrer" />

      {/* Before (clipped) */}
      <div className="absolute inset-0 overflow-hidden" style={{ width: `${position}%` }}>
        <img src={project.before} alt="Before" className="absolute inset-0 w-full h-full object-cover" style={{ width: containerRef.current ? `${containerRef.current.offsetWidth}px` : '100%' }} referrerPolicy="no-referrer" />
      </div>

      {/* Divider */}
      <div className="absolute top-0 bottom-0 z-10" style={{ left: `${position}%`, transform: 'translateX(-50%)' }}>
        <div className="w-[2px] h-full bg-white shadow-lg" />
        <div className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 w-10 h-10 bg-white rounded-full shadow-xl flex items-center justify-center">
          <ArrowLeftRight size={16} className="text-[#c8872b]" />
        </div>
      </div>

      {/* Labels */}
      <div className="absolute top-4 left-4 px-3 py-1.5 bg-[#1a1612]/80 backdrop-blur-sm text-white text-[10px] font-bold uppercase tracking-wider rounded-full font-sans z-20">Before</div>
      <div className="absolute top-4 right-4 px-3 py-1.5 bg-[#c8872b]/90 backdrop-blur-sm text-white text-[10px] font-bold uppercase tracking-wider rounded-full font-sans z-20">After</div>
    </div>
  );
}

export default function BeforeAfter() {
  const [activeIdx, setActiveIdx] = useState(0);

  return (
    <section className="py-24 bg-[var(--color-brand-cream)] dark:bg-[#1a1612] transition-colors duration-300">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-xs font-bold text-[#c8872b] uppercase tracking-[0.25em] mb-4 font-sans">Our Work</h2>
          <p className="text-4xl lg:text-5xl font-display text-stone-900 dark:text-stone-100 mb-4">See the Transformation</p>
          <p className="text-stone-500 dark:text-stone-400 max-w-xl mx-auto font-medium">
            Drag the slider to compare. Every job is documented with before/after photos and a comprehensive summary.
          </p>
        </div>

        <div className="grid lg:grid-cols-5 gap-10 items-start">
          {/* Slider */}
          <div className="lg:col-span-3">
            <motion.div key={activeIdx} initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.3 }}>
              <Slider project={projects[activeIdx]} />
            </motion.div>
          </div>

          {/* Project list */}
          <div className="lg:col-span-2 space-y-4">
            {projects.map((project, idx) => (
              <button
                key={idx}
                onClick={() => setActiveIdx(idx)}
                className={`w-full text-left p-5 rounded-2xl border transition-all ${activeIdx === idx
                    ? 'bg-white dark:bg-[#292117] border-[#c8872b]/40 shadow-lg shadow-amber-900/5'
                    : 'bg-white/50 dark:bg-[#292117]/50 border-stone-200 dark:border-stone-700/50 hover:border-[#c8872b]/20'
                  }`}
              >
                <div className="flex items-center gap-2 mb-2">
                  <h3 className={`font-display text-lg ${activeIdx === idx ? 'text-[#c8872b]' : 'text-stone-900 dark:text-stone-100'}`}>
                    {project.title}
                  </h3>
                  <span className="text-[10px] font-bold text-stone-400 dark:text-stone-500 uppercase tracking-wider font-sans">{project.location}</span>
                </div>
                <p className="text-sm text-stone-500 dark:text-stone-400 leading-relaxed">{project.description}</p>
              </button>
            ))}

            <p className="text-xs text-stone-400 dark:text-stone-500 italic mt-4 pl-1">
              Clear, plain-language summaries accompany every report in your Client Portal.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
