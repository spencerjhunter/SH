import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Send, User, Bot, Loader2, CheckCircle2 } from 'lucide-react';
import { getChatResponse } from '@/src/services/gemini';
import { cn } from '@/src/lib/utils';

interface Message { role: 'user' | 'model'; text: string; }
interface ChatIntakeProps { systemInstruction: string; initialMessage: string; onComplete?: (data: any) => void; context?: string; }

export default function ChatIntake({ systemInstruction, initialMessage, onComplete }: ChatIntakeProps) {
  const [messages, setMessages] = useState<Message[]>([{ role: 'model', text: initialMessage }]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isCompleted, setIsCompleted] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => { if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight; }, [messages, isLoading]);

  const handleSend = async (e?: React.FormEvent) => {
    e?.preventDefault();
    if (!input.trim() || isLoading || isCompleted) return;
    const userMessage = input.trim();
    setInput('');
    setMessages(prev => [...prev, { role: 'user', text: userMessage }]);
    setIsLoading(true);
    try {
      const history = messages.map(m => ({ role: m.role === 'user' ? 'user' : 'model' as const, parts: [{ text: m.text }] }));
      history.push({ role: 'user', parts: [{ text: userMessage }] });
      const response = await getChatResponse(history, systemInstruction);
      if (response) {
        setMessages(prev => [...prev, { role: 'model', text: response }]);
        if (response.toLowerCase().includes('thank you') && response.toLowerCase().includes('submitted')) {
          setIsCompleted(true);
          if (onComplete) onComplete({});
        }
      }
    } catch { setMessages(prev => [...prev, { role: 'model', text: "I'm sorry, I encountered an error. Could you please try again?" }]); }
    finally { setIsLoading(false); }
  };

  return (
    <div className="flex flex-col h-full bg-white dark:bg-[#292117] rounded-2xl border border-stone-200 dark:border-stone-700/50 shadow-xl overflow-hidden transition-colors duration-300">
      <div ref={scrollRef} className="flex-1 overflow-y-auto p-6 space-y-4 bg-[var(--color-brand-cream)]/30 dark:bg-[#1a1612]/30">
        {messages.map((msg, i) => (
          <motion.div key={i} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className={cn("flex items-start gap-3", msg.role === 'user' ? "flex-row-reverse" : "flex-row")}>
            <div className={cn("w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0",
              msg.role === 'user' ? "bg-[#c8872b] text-white" : "bg-white dark:bg-stone-800 border border-stone-200 dark:border-stone-700 text-[#c8872b]"
            )}>{msg.role === 'user' ? <User size={14} /> : <Bot size={14} />}</div>
            <div className={cn("max-w-[80%] p-4 rounded-2xl text-sm shadow-sm",
              msg.role === 'user' ? "bg-[#c8872b] text-white rounded-tr-none" : "bg-white dark:bg-stone-800 text-stone-700 dark:text-stone-200 rounded-tl-none border border-stone-200/60 dark:border-stone-700"
            )}>{msg.text}</div>
          </motion.div>
        ))}
        {isLoading && (
          <div className="flex items-start gap-3">
            <div className="w-8 h-8 rounded-full bg-white dark:bg-stone-800 border border-stone-200 dark:border-stone-700 text-[#c8872b] flex items-center justify-center"><Bot size={14} /></div>
            <div className="bg-white dark:bg-stone-800 border border-stone-200/60 dark:border-stone-700 p-4 rounded-2xl rounded-tl-none shadow-sm"><Loader2 size={14} className="animate-spin text-[#c8872b]" /></div>
          </div>
        )}
        {isCompleted && (
          <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} className="flex flex-col items-center justify-center p-8 text-center space-y-4">
            <div className="w-16 h-16 bg-[#e8efe9] dark:bg-emerald-900/20 text-[#5a7a5f] rounded-full flex items-center justify-center"><CheckCircle2 size={32} /></div>
            <h3 className="text-xl font-display text-stone-900 dark:text-stone-100">Information Gathered!</h3>
            <p className="text-stone-500 dark:text-stone-400 text-sm">Your request has been successfully processed.</p>
          </motion.div>
        )}
      </div>
      {!isCompleted && (
        <div className="p-4 bg-white dark:bg-[#292117] border-t border-stone-200/60 dark:border-stone-700/50">
          <form onSubmit={handleSend} className="flex items-center gap-2">
            <input type="text" value={input} onChange={(e) => setInput(e.target.value)} disabled={isLoading} placeholder="Type your response..."
              className="flex-1 px-4 py-3 bg-stone-50 dark:bg-stone-800 border border-stone-200 dark:border-stone-700 rounded-xl outline-none focus:ring-2 focus:ring-[#c8872b] transition-all text-sm dark:text-stone-200" />
            <button type="submit" disabled={isLoading || !input.trim()}
              className="w-11 h-11 bg-[#c8872b] text-white rounded-xl flex items-center justify-center shadow-lg shadow-amber-900/15 hover:bg-[#b47825] transition-all disabled:opacity-50"><Send size={18} /></button>
          </form>
        </div>
      )}
    </div>
  );
}
