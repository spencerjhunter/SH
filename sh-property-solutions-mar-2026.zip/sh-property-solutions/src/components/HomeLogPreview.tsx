import React from 'react';
import { motion } from 'motion/react';
import { FileText, Droplets, Paintbrush, Thermometer, Calendar, MapPin, Shield } from 'lucide-react';

const logEntries = [
  { icon: Droplets, label: 'Main Water Shut-Off', value: 'Basement, NW corner — red handle', updated: 'Jan 2026' },
  { icon: Thermometer, label: 'Furnace Filter', value: '20×25×4 MERV-11 — Honeywell', updated: 'Feb 2026' },
  { icon: Paintbrush, label: 'Interior Paint', value: 'SW 7015 "Repose Gray" — eggshell', updated: 'Nov 2025' },
  { icon: Shield, label: 'Roof Age', value: 'Installed 2019 — 30-yr architectural', updated: 'Mar 2026' },
  { icon: Calendar, label: 'Last Seasonal Inspection', value: 'Fall 20-Point — Oct 12, 2025', updated: 'Oct 2025' },
  { icon: MapPin, label: 'Septic Location', value: 'South yard, 35ft from deck — pumped Aug 2025', updated: 'Aug 2025' },
];

export default function HomeLogPreview() {
  return (
    <section className="py-24 bg-white dark:bg-[#292117]/50 transition-colors duration-300">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Description */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
          >
            <h2 className="text-xs font-bold text-[#c8872b] uppercase tracking-[0.25em] mb-4 font-sans">Exclusive Feature</h2>
            <p className="text-4xl lg:text-5xl font-display text-stone-900 dark:text-stone-100 mb-6">Your Interactive Home Log</p>
            <p className="text-stone-500 dark:text-stone-400 text-lg leading-relaxed mb-8 font-medium">
              No more guessing your filter size, hunting for paint codes, or forgetting where the shut-off valve is. Every property gets a detailed, living record that updates with every service call.
            </p>
            <div className="space-y-4 mb-8">
              {['Updated automatically with every job', 'Accessible anytime from your Client Portal', 'Shared securely with your landlord or service team', 'Included free with all Stewardship plans'].map((item) => (
                <div key={item} className="flex items-center gap-3 text-sm text-stone-600 dark:text-stone-300 font-medium">
                  <div className="w-5 h-5 bg-[#e8efe9] dark:bg-emerald-900/15 text-[#5a7a5f] rounded flex items-center justify-center flex-shrink-0">
                    <svg width="10" height="8" viewBox="0 0 10 8" fill="none"><path d="M1 4L3.5 6.5L9 1" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" /></svg>
                  </div>
                  {item}
                </div>
              ))}
            </div>
            <p className="text-xs text-stone-400 dark:text-stone-500 italic">No competitor in the Highway 95 corridor offers this.</p>
          </motion.div>

          {/* Preview Card */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="relative"
          >
            <div className="bg-[var(--color-brand-cream)] dark:bg-[#1a1612] rounded-2xl border border-stone-200 dark:border-stone-700/50 shadow-2xl shadow-stone-900/10 overflow-hidden">
              {/* Header */}
              <div className="p-5 bg-[#1a1612] text-stone-100 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 bg-[#c8872b] rounded-lg flex items-center justify-center"><FileText size={18} /></div>
                  <div>
                    <div className="font-display text-sm">Lakefront Cabin</div>
                    <div className="text-[10px] text-stone-400 font-sans">New Meadows, ID &middot; Last updated Mar 2026</div>
                  </div>
                </div>
                <div className="px-2 py-1 bg-[#5a7a5f]/20 text-[#8ab08f] text-[9px] font-bold uppercase tracking-wider rounded font-sans">Live</div>
              </div>

              {/* Entries */}
              <div className="divide-y divide-stone-200/60 dark:divide-stone-700/30">
                {logEntries.map((entry) => (
                  <div key={entry.label} className="px-5 py-4 flex items-start gap-4 hover:bg-white/50 dark:hover:bg-stone-800/20 transition-colors">
                    <div className="w-9 h-9 bg-amber-50 dark:bg-amber-900/15 text-[#c8872b] rounded-lg flex items-center justify-center flex-shrink-0 mt-0.5">
                      <entry.icon size={16} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="text-[10px] font-bold text-stone-400 dark:text-stone-500 uppercase tracking-wider mb-0.5 font-sans">{entry.label}</div>
                      <div className="text-sm font-medium text-stone-800 dark:text-stone-200">{entry.value}</div>
                    </div>
                    <div className="text-[10px] text-stone-400 dark:text-stone-500 font-sans whitespace-nowrap mt-1">{entry.updated}</div>
                  </div>
                ))}
              </div>

              {/* Footer */}
              <div className="px-5 py-3 bg-stone-50 dark:bg-stone-800/30 text-center">
                <span className="text-[10px] text-stone-400 dark:text-stone-500 font-bold uppercase tracking-wider font-sans">Sample Preview &middot; Your log will be unique to your property</span>
              </div>
            </div>

            {/* Decorative accents */}
            <div className="absolute -bottom-3 -right-3 w-20 h-20 bg-[#c8872b]/10 rounded-xl -z-10" />
            <div className="absolute -top-3 -left-3 w-14 h-14 bg-[#5a7a5f]/10 rounded-xl -z-10" />
          </motion.div>
        </div>
      </div>
    </section>
  );
}
