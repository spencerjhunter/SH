import React from 'react';
import { motion } from 'motion/react';
import { Hammer, Shield, Leaf, Snowflake, Camera, Cpu, Wrench, Home } from 'lucide-react';

const services = [
  { title: 'Maintenance Requests', description: 'Tenants submit requests easily. Issues are triaged, documented, and routed quickly.', icon: Wrench, accent: 'bg-amber-50 text-[#c8872b] dark:bg-amber-900/15 dark:text-amber-400' },
  { title: 'Seasonal Checklists', description: 'Spring & Fall 20-point inspections with detailed health reports for landlords.', icon: Leaf, accent: 'bg-[#e8efe9] text-[#5a7a5f] dark:bg-emerald-900/15 dark:text-emerald-400' },
  { title: 'Snowbird Watch', description: 'Monthly visual inspections with video walkthroughs for remote owners.', icon: Snowflake, accent: 'bg-sky-50 text-sky-600 dark:bg-sky-900/15 dark:text-sky-400' },
  { title: 'General Handyman', description: 'Expert repairs, finish carpentry, drywall, painting, and installations.', icon: Hammer, accent: 'bg-stone-100 text-stone-600 dark:bg-stone-800 dark:text-stone-400' },
  { title: 'System Monitoring', description: 'Sensor integration for generators, wells, septic, and solar — monitored and maintained.', icon: Cpu, accent: 'bg-violet-50 text-violet-600 dark:bg-violet-900/15 dark:text-violet-400' },
  { title: 'Digital Home Log', description: "A living record of every property — filter sizes, paint codes, shut-off valves, and more.", icon: Camera, accent: 'bg-rose-50 text-rose-600 dark:bg-rose-900/15 dark:text-rose-400' },
  { title: 'Licensed Trade Referrals', description: 'Electrical, plumbing, and HVAC routed to vetted, licensed subcontractors.', icon: Shield, accent: 'bg-amber-50 text-[#c8872b] dark:bg-amber-900/15 dark:text-amber-400' },
  { title: 'Property Management', description: 'Full-service support for landlords — tenant communication, billing, transparent reporting.', icon: Home, accent: 'bg-[#e8efe9] text-[#5a7a5f] dark:bg-emerald-900/15 dark:text-emerald-400' },
];

export default function Services() {
  return (
    <section className="py-24 bg-white dark:bg-[#292117]/50 transition-colors duration-300">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-xs font-bold text-[#c8872b] uppercase tracking-[0.25em] mb-4 font-sans">Our Services</h2>
          <p className="text-4xl lg:text-5xl font-display text-stone-900 dark:text-stone-100 mb-4">Everything Your Property Needs</p>
          <p className="text-stone-500 dark:text-stone-400 max-w-2xl mx-auto font-medium">
            Dependable property maintenance and management for tenants, homeowners, and landlords along the Highway 95 corridor.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {services.map((service, index) => (
            <motion.div
              key={service.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.08 }}
              className="group p-7 bg-[var(--color-brand-cream)] dark:bg-[#1a1612] rounded-2xl border border-stone-200/80 dark:border-stone-700/40 hover:shadow-xl hover:shadow-amber-900/5 transition-all duration-300 hover:-translate-y-1"
            >
              <div className={`w-14 h-14 ${service.accent} rounded-xl flex items-center justify-center mb-5 transition-transform group-hover:scale-110 group-hover:rotate-2`}>
                <service.icon size={26} />
              </div>
              <h3 className="text-lg font-display text-stone-900 dark:text-stone-100 mb-2">{service.title}</h3>
              <p className="text-stone-500 dark:text-stone-400 text-sm leading-relaxed">{service.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
