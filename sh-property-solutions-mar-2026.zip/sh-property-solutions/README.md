# SH Property Solutions — Highway 95 Corridor Webapp

Tech-enabled property management and handyman services for Idaho's Highway 95 corridor (Midvale → Council → New Meadows).

## Quick Start

```bash
npm install
npm run dev
```

Requires a `GEMINI_API_KEY` in your environment (auto-injected in Google AI Studio).

## Stack
- React 19 + TypeScript + Vite
- Tailwind CSS v4
- Motion (Framer Motion) for animations
- Google Gemini API for AI chat intake
- React Router v7

## Pages
- `/` — Homepage (10 sections: Hero, Services, How It Works, Digital Home Log, Before/After, Pricing, Comparison, Service Area, Reviews, FAQ)
- `/maintenance` — AI-powered service request intake
- `/communication` — Client Portal (messaging, Video Vault, Home Log, Reports)
- `/billing` — Stewardship subscription billing & invoices
- `/blog` — The Corridor Chronicle (blog, vlogs, email capture)
- `/onboarding` — 3-path onboarding (Tenant, Service Pro, Landlord)
- `/services/new-meadows` — SEO landing page for New Meadows
- `/services/council` — SEO landing page for Council
- `/services/midvale` — SEO landing page for Midvale

## Design System
- **Typography**: DM Serif Display (headlines) + Plus Jakarta Sans (body)
- **Palette**: Warm amber (#c8872b), sage green (#5a7a5f), warm cream (#faf6f0), charcoal (#1a1612)
- **Dark mode**: Full support throughout
