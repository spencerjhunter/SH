import React from 'react';
import { render, screen } from '@testing-library/react';
import { describe, it, expect } from 'vitest';
import { BrowserRouter } from 'react-router-dom';
import Home from '../src/pages/Home';

describe('Home Page', () => {
    it('renders the main heading', () => {
        render(
            <BrowserRouter>
                <Home />
            </BrowserRouter>
        );
        // Focus on finding key elements that don't rely heavily on exact copy
        // since we'll be changing the copy.
        expect(screen.getAllByText(/Your Property's/i)[0]).toBeInTheDocument();
    });
});
